export interface Product {
  id: string;
  slug: string;
  name: string;
  tagline: string | null;
  description: string | null;
  image_url: string | null;
  category: string | null;
  pricing_type: 'flat' | 'tiered' | 'per_session' | 'per_project';
  billing_type: 'one_time' | 'recurring';
  booking_required: boolean;
  starting_price: number;
  is_active: boolean;
  sort_order: number;
  created_at: string;
}

export interface ProductTier {
  id: string;
  product_id: string;
  tier_name: string;
  price: number;
  description: string | null;
  features: string[];
  sort_order: number;
}

export interface TeamMember {
  id: string;
  full_name: string;
  bio: string;
  photo_url: string | null;
  sort_order: number;
  created_at: string;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string | null;
  content: string | null;
  image_url: string | null;
  category: string | null;
  author: string | null;
  published: boolean;
  published_at: string | null;
  created_at: string;
}

export interface Program {
  id: string;
  title: string;
  slug: string;
  description: string | null;
  image_url: string | null;
  program_type: string;
  event_date: string | null;
  location: string | null;
  capacity: number | null;
  is_active: boolean;
  created_at: string;
}

export interface Order {
  id: string;
  user_id: string;
  order_number: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  subtotal: number;
  tax: number;
  discount: number;
  total: number;
  currency: string;
  customer_name: string | null;
  customer_email: string | null;
  customer_phone: string | null;
  promo_code: string | null;
  payment_method: string | null;
  consultation_mode: string | null;
  notes: string | null;
  created_at: string;
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string | null;
  product_name: string;
  tier_name: string | null;
  quantity: number;
  unit_price: number;
  line_total: number;
  billing_type: string;
  booking_date: string | null;
  booking_time_slot: string | null;
  consultation_mode: string | null;
}

export interface Subscription {
  id: string;
  user_id: string;
  product_id: string | null;
  tier_name: string | null;
  status: 'active' | 'cancelled' | 'past_due' | 'trialing';
  amount: number;
  billing_cycle: string;
  current_period_start: string;
  current_period_end: string | null;
  cancelled_at: string | null;
  created_at: string;
}

export interface Booking {
  id: string;
  user_id: string;
  order_id: string | null;
  product_id: string | null;
  booking_date: string;
  time_slot: string;
  consultation_mode: 'online' | 'offline';
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  meeting_link: string | null;
  location: string | null;
  notes: string | null;
  created_at: string;
}

export interface CustomQuote {
  id: string;
  user_id: string | null;
  product_id: string | null;
  name: string;
  email: string;
  phone: string | null;
  project_brief: string;
  budget_range: string | null;
  timeline: string | null;
  status: 'pending' | 'quoted' | 'accepted' | 'declined';
  quoted_price: number | null;
  created_at: string;
}

export interface PromoCode {
  id: string;
  code: string;
  discount_type: 'percentage' | 'fixed';
  discount_value: number;
  max_uses: number | null;
  used_count: number;
  is_active: boolean;
  expires_at: string | null;
  created_at: string;
}

export interface ContactSubmission {
  id: string;
  user_id: string | null;
  name: string;
  email: string;
  phone: string | null;
  submission_type: 'contact' | 'join' | 'partnership';
  message: string;
  status: 'new' | 'responded' | 'closed';
  created_at: string;
}

export interface HeroSettings {
  id: string;
  background_image_url: string | null;
  headline: string | null;
  subheadline: string | null;
  updated_at: string;
}

export interface CartItem {
  productId: string;
  slug: string;
  name: string;
  image_url: string | null;
  tierName: string | null;
  tierId: string | null;
  unitPrice: number;
  quantity: number;
  billingType: 'one_time' | 'recurring';
  bookingRequired: boolean;
  bookingDate: string | null;
  bookingTimeSlot: string | null;
  consultationMode: 'online' | 'offline' | null;
  cartItemId: string;
}
