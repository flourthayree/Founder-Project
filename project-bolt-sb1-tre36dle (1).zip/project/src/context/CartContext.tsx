import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import type { CartItem } from '../types';

interface CartContextValue {
  items: CartItem[];
  addItem: (item: Omit<CartItem, 'cartItemId'>) => void;
  removeItem: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, quantity: number) => void;
  updateBooking: (cartItemId: string, booking: { bookingDate: string; bookingTimeSlot: string; consultationMode: 'online' | 'offline' }) => void;
  clearCart: () => void;
  subtotal: number;
  oneTimeSubtotal: number;
  recurringSubtotal: number;
  itemCount: number;
}

const CartContext = createContext<CartContextValue | undefined>(undefined);

const STORAGE_KEY = 'founder_project_cart';

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  }, [items]);

  const addItem = (item: Omit<CartItem, 'cartItemId'>) => {
    const cartItemId = `${item.productId}-${item.tierId || 'default'}-${Date.now()}`;
    setItems((prev) => [...prev, { ...item, cartItemId }]);
  };

  const removeItem = (cartItemId: string) => {
    setItems((prev) => prev.filter((i) => i.cartItemId !== cartItemId));
  };

  const updateQuantity = (cartItemId: string, quantity: number) => {
    if (quantity < 1) return;
    setItems((prev) => prev.map((i) => (i.cartItemId === cartItemId ? { ...i, quantity } : i)));
  };

  const updateBooking = (cartItemId: string, booking: { bookingDate: string; bookingTimeSlot: string; consultationMode: 'online' | 'offline' }) => {
    setItems((prev) => prev.map((i) => (i.cartItemId === cartItemId ? { ...i, ...booking } : i)));
  };

  const clearCart = () => setItems([]);

  const oneTimeSubtotal = items
    .filter((i) => i.billingType === 'one_time')
    .reduce((sum, i) => sum + i.unitPrice * i.quantity, 0);

  const recurringSubtotal = items
    .filter((i) => i.billingType === 'recurring')
    .reduce((sum, i) => sum + i.unitPrice * i.quantity, 0);

  const subtotal = oneTimeSubtotal + recurringSubtotal;
  const itemCount = items.reduce((sum, i) => sum + i.quantity, 0);

  return (
    <CartContext.Provider
      value={{ items, addItem, removeItem, updateQuantity, updateBooking, clearCart, subtotal, oneTimeSubtotal, recurringSubtotal, itemCount }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}
