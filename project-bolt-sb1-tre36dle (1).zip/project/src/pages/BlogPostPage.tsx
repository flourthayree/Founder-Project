import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Calendar, User, ArrowRight } from 'lucide-react';
import { useBlogPost } from '../hooks/useData';
import { formatDate } from '../lib/utils';

export default function BlogPostPage() {
  const { slug } = useParams<{ slug: string }>();
  const { post, loading } = useBlogPost(slug || '');

  if (loading) {
    return (
      <div className="pt-32 pb-16">
        <div className="container-max px-4">
          <div className="card h-96 animate-pulse bg-gray-100" />
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="pt-32 pb-16 text-center">
        <div className="container-max px-4">
          <h1 className="font-heading font-extrabold text-3xl text-navy-800 mb-4">Article Not Found</h1>
          <Link to="/blog" className="btn-primary">Back to Blog</Link>
        </div>
      </div>
    );
  }

  const paragraphs = post.content?.split('\n\n') || [];

  return (
    <div>
      <section className="bg-navy-800 pt-32 pb-12 relative overflow-hidden">
        <div className="absolute inset-0 dotted-pattern opacity-20" />
        <div className="container-max px-4 sm:px-6 lg:px-8 relative z-10">
          <Link to="/blog" className="inline-flex items-center gap-2 text-navy-200 hover:text-white transition-colors mb-6">
            <ArrowLeft className="w-4 h-4" /> Back to Blog
          </Link>
          <span className="text-sm font-semibold text-navy-200 uppercase tracking-wider">{post.category}</span>
          <h1 className="font-heading font-extrabold text-3xl lg:text-4xl text-white mt-2 mb-4 max-w-3xl">{post.title}</h1>
          <div className="flex items-center gap-4 text-navy-200 text-sm">
            <span className="flex items-center gap-1.5"><User className="w-4 h-4" /> {post.author}</span>
            <span className="flex items-center gap-1.5"><Calendar className="w-4 h-4" /> {post.published_at ? formatDate(post.published_at) : ''}</span>
          </div>
        </div>
      </section>

      <article className="section-padding bg-white">
        <div className="container-max max-w-3xl">
          {post.image_url && (
            <div className="card overflow-hidden rounded-2xl mb-8">
              <img src={post.image_url} alt={post.title} className="w-full h-64 lg:h-96 object-cover" />
            </div>
          )}
          <div className="prose prose-lg max-w-none">
            {paragraphs.map((para, i) => {
              if (para.startsWith('## ')) {
                return <h2 key={i} className="font-heading font-bold text-2xl text-navy-800 mt-8 mb-4">{para.replace('## ', '')}</h2>;
              }
              return <p key={i} className="text-navy-800 leading-relaxed mb-4 text-lg">{para}</p>;
            })}
          </div>

          <div className="border-t border-gray-100 mt-12 pt-8">
            <Link to="/blog" className="inline-flex items-center gap-2 text-navy-500 hover:text-navy-800 transition-colors font-medium">
              <ArrowRight className="w-4 h-4 rotate-180" /> Back to All Articles
            </Link>
          </div>
        </div>
      </article>

      <section className="bg-navy-800 py-16">
        <div className="container-max text-center">
          <h2 className="font-heading font-extrabold text-2xl text-white mb-4">Ready to Work With Us?</h2>
          <p className="text-navy-200 mb-6">Explore our professional services for your brand.</p>
          <Link to="/services" className="btn-accent group">
            View Services <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>
    </div>
  );
}
