import { useState } from 'react';
import { Mail, Phone, MapPin, Send, Check, Users, Handshake, MessageSquare } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

const submissionTypes = [
  { id: 'contact', label: 'General Inquiry', icon: MessageSquare, desc: 'Questions about our services or anything else.' },
  { id: 'join', label: 'Join the Community', icon: Users, desc: 'Want to become a member or join our team?' },
  { id: 'partnership', label: 'Partnership', icon: Handshake, desc: 'Interested in collaborating with us?' },
];

export default function ContactPage() {
  const { user } = useAuth();
  const [name, setName] = useState(user?.email?.split('@')[0] || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState('');
  const [submissionType, setSubmissionType] = useState('contact');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!name || !email || !message) {
      setError('Please fill in all required fields.');
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.from('contact_submissions').insert({
      name,
      email,
      phone: phone || null,
      submission_type: submissionType,
      message,
    });
    setSubmitting(false);
    if (error) {
      setError('Failed to submit. Please try again.');
      return;
    }
    setSubmitted(true);
    setName('');
    setEmail('');
    setPhone('');
    setMessage('');
  };

  return (
    <div>
      <section className="bg-navy-800 pt-32 pb-16 relative overflow-hidden">
        <div className="absolute inset-0 dotted-pattern opacity-20" />
        <div className="container-max px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <h1 className="font-heading font-extrabold text-4xl lg:text-5xl text-white mb-4">Get in Touch</h1>
          <p className="text-navy-200 text-lg max-w-2xl mx-auto">
            Have a question, want to join our community, or interested in a partnership? We would love to hear from you.
          </p>
        </div>
      </section>

      <section className="section-padding bg-neutral-light">
        <div className="container-max">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Contact Info */}
            <div className="space-y-6">
              <div className="card p-6">
                <div className="bg-navy-800 rounded-xl p-3 w-fit mb-4">
                  <Mail className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-heading font-bold text-navy-800 mb-1">Email Us</h3>
                <p className="text-neutral-gray text-sm mb-2">For any inquiries</p>
                <a href="mailto:hello@founderproject.id" className="text-navy-500 hover:text-navy-800 transition-colors font-medium">
                  hello@founderproject.id
                </a>
              </div>
              <div className="card p-6">
                <div className="bg-navy-800 rounded-xl p-3 w-fit mb-4">
                  <Phone className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-heading font-bold text-navy-800 mb-1">Call Us</h3>
                <p className="text-neutral-gray text-sm mb-2">Mon-Fri, 9am-5pm</p>
                <a href="tel:+6281234567890" className="text-navy-500 hover:text-navy-800 transition-colors font-medium">
                  +62 812 3456 7890
                </a>
              </div>
              <div className="card p-6">
                <div className="bg-navy-800 rounded-xl p-3 w-fit mb-4">
                  <MapPin className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-heading font-bold text-navy-800 mb-1">Visit Us</h3>
                <p className="text-neutral-gray text-sm mb-2">Our studio</p>
                <span className="text-navy-500 font-medium">Jakarta, Indonesia</span>
              </div>
            </div>

            {/* Form */}
            <div className="lg:col-span-2">
              <div className="card p-6 lg:p-8">
                {submitted ? (
                  <div className="text-center py-12">
                    <div className="bg-green-100 rounded-full p-6 w-fit mx-auto mb-6">
                      <Check className="w-12 h-12 text-green-600" />
                    </div>
                    <h2 className="font-heading font-extrabold text-2xl text-navy-800 mb-2">Message Sent!</h2>
                    <p className="text-neutral-gray mb-6">Thank you for reaching out. We will get back to you within 2-3 business days.</p>
                    <button onClick={() => setSubmitted(false)} className="btn-secondary">
                      Send Another Message
                    </button>
                  </div>
                ) : (
                  <>
                    <h2 className="font-heading font-bold text-2xl text-navy-800 mb-2">Send a Message</h2>
                    <p className="text-neutral-gray text-sm mb-6">Fill out the form below and we will respond as soon as possible.</p>

                    {/* Submission Type */}
                    <div className="grid grid-cols-3 gap-3 mb-6">
                      {submissionTypes.map((type) => (
                        <button
                          key={type.id}
                          onClick={() => setSubmissionType(type.id)}
                          className={`p-4 rounded-xl border-2 transition-all text-center ${
                            submissionType === type.id
                              ? 'border-navy-800 bg-navy-50'
                              : 'border-gray-200 hover:border-navy-300'
                          }`}
                        >
                          <type.icon className={`w-5 h-5 mx-auto mb-2 ${submissionType === type.id ? 'text-navy-800' : 'text-neutral-gray'}`} />
                          <span className={`text-xs font-semibold block ${submissionType === type.id ? 'text-navy-800' : 'text-neutral-gray'}`}>
                            {type.label}
                          </span>
                        </button>
                      ))}
                    </div>

                    <p className="text-sm text-neutral-gray mb-4">
                      {submissionTypes.find((t) => t.id === submissionType)?.desc}
                    </p>

                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium text-navy-800 mb-1 block">Full Name *</label>
                          <input type="text" value={name} onChange={(e) => setName(e.target.value)} className="input-field" placeholder="Your name" required />
                        </div>
                        <div>
                          <label className="text-sm font-medium text-navy-800 mb-1 block">Phone Number</label>
                          <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} className="input-field" placeholder="+62 812 3456 7890" />
                        </div>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-navy-800 mb-1 block">Email Address *</label>
                        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="input-field" placeholder="you@example.com" required />
                      </div>
                      <div>
                        <label className="text-sm font-medium text-navy-800 mb-1 block">Message *</label>
                        <textarea
                          value={message}
                          onChange={(e) => setMessage(e.target.value)}
                          className="input-field min-h-[120px] resize-y"
                          placeholder={submissionType === 'join' ? 'Tell us about yourself and why you want to join...' : 'How can we help you?'}
                          required
                        />
                      </div>
                      {error && <p className="text-sm text-red-500">{error}</p>}
                      <button type="submit" disabled={submitting} className="btn-primary w-full sm:w-auto group">
                        {submitting ? 'Sending...' : (
                          <>
                            <Send className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                            Send Message
                          </>
                        )}
                      </button>
                    </form>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
