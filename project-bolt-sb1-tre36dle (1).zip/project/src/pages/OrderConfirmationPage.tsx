import { useParams, Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import {
  CheckCircle, Download, Calendar, Video, MapPin, ArrowRight, Mail, Clock,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { formatPrice, formatDate } from '../lib/utils';
import type { Order, OrderItem, Booking } from '../types';

export default function OrderConfirmationPage() {
  const { orderNumber } = useParams<{ orderNumber: string }>();
  const [order, setOrder] = useState<Order | null>(null);
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data: orderData } = await supabase
        .from('orders')
        .select('*')
        .eq('order_number', orderNumber)
        .maybeSingle();

      if (orderData) {
        setOrder(orderData);
        const { data: items } = await supabase
          .from('order_items')
          .select('*')
          .eq('order_id', orderData.id);
        setOrderItems(items || []);

        const { data: bookingData } = await supabase
          .from('bookings')
          .select('*')
          .eq('order_id', orderData.id);
        setBookings(bookingData || []);
      }
      setLoading(false);
    })();
  }, [orderNumber]);

  const downloadInvoice = () => {
    if (!order) return;
    const invoiceContent = `
THE FOUNDER PROJECT
====================
Invoice: ${order.order_number}
Date: ${formatDate(order.created_at)}
Status: ${order.status.toUpperCase()}

Customer:
${order.customer_name}
${order.customer_email}
${order.customer_phone}

Items:
${orderItems.map((item) => `- ${item.product_name}${item.tier_name ? ` (${item.tier_name})` : ''} x${item.quantity}: ${formatPrice(item.line_total)}`).join('\n')}

Subtotal: ${formatPrice(order.subtotal)}
Tax: ${formatPrice(order.tax)}
${order.discount > 0 ? `Discount: -${formatPrice(order.discount)}\n` : ''}Total: ${formatPrice(order.total)}

Payment Method: ${order.payment_method}

Thank you for choosing The Founder Project!
    `.trim();

    const blob = new Blob([invoiceContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `invoice-${order.order_number}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="pt-32 pb-16 min-h-[60vh] flex items-center">
        <div className="container-max px-4 text-center">
          <div className="animate-pulse">Loading...</div>
        </div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="pt-32 pb-16 min-h-[60vh] flex items-center">
        <div className="container-max px-4 text-center">
          <h1 className="font-heading font-extrabold text-3xl text-navy-800 mb-3">Order Not Found</h1>
          <p className="text-neutral-gray mb-6">We could not find this order.</p>
          <Link to="/services" className="btn-primary">Back to Services</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-16 bg-neutral-light min-h-screen">
      <div className="container-max px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          {/* Success Header */}
          <div className="text-center mb-8">
            <div className="bg-green-100 rounded-full p-6 w-fit mx-auto mb-6 animate-scale-in">
              <CheckCircle className="w-16 h-16 text-green-600" />
            </div>
            <h1 className="font-heading font-extrabold text-3xl text-navy-800 mb-2">Order Confirmed!</h1>
            <p className="text-neutral-gray text-lg">Thank you for your order. We have sent a confirmation to your email.</p>
            <div className="inline-block bg-navy-50 px-4 py-2 rounded-lg mt-4">
              <span className="text-sm text-neutral-gray">Order Number: </span>
              <span className="font-heading font-bold text-navy-800">{order.order_number}</span>
            </div>
          </div>

          {/* Booking Details */}
          {bookings.length > 0 && (
            <div className="card p-6 mb-6">
              <h2 className="font-heading font-bold text-xl text-navy-800 mb-4 flex items-center gap-2">
                <Calendar className="w-5 h-5" /> Session Details
              </h2>
              <div className="space-y-4">
                {bookings.map((booking) => (
                  <div key={booking.id} className="border border-gray-200 rounded-xl p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span className="font-semibold text-navy-800">Confirmed</span>
                    </div>
                    <div className="grid sm:grid-cols-2 gap-3 text-sm">
                      <div className="flex items-center gap-2 text-navy-800">
                        <Calendar className="w-4 h-4 text-neutral-gray" />
                        {formatDate(booking.booking_date)}
                      </div>
                      <div className="flex items-center gap-2 text-navy-800">
                        <Clock className="w-4 h-4 text-neutral-gray" />
                        {booking.time_slot}
                      </div>
                      {booking.consultation_mode === 'online' ? (
                        <div className="flex items-center gap-2 text-navy-800">
                          <Video className="w-4 h-4 text-neutral-gray" />
                          Online Session
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 text-navy-800">
                          <MapPin className="w-4 h-4 text-neutral-gray" />
                          {booking.location || 'In-Studio'}
                        </div>
                      )}
                    </div>
                    {booking.meeting_link && (
                      <div className="mt-3 p-3 bg-navy-50 rounded-lg">
                        <div className="flex items-center gap-2 text-sm">
                          <Video className="w-4 h-4 text-navy-800" />
                          <span className="text-navy-800 font-medium">Meeting Link: </span>
                          <a href={booking.meeting_link} target="_blank" rel="noopener noreferrer" className="text-navy-500 hover:text-navy-800 underline break-all">
                            {booking.meeting_link}
                          </a>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Order Summary */}
          <div className="card p-6 mb-6">
            <h2 className="font-heading font-bold text-xl text-navy-800 mb-4">Order Summary</h2>
            <div className="space-y-3 mb-4">
              {orderItems.map((item) => (
                <div key={item.id} className="flex justify-between text-sm">
                  <div>
                    <span className="font-semibold text-navy-800">{item.product_name}</span>
                    {item.tier_name && <span className="text-neutral-gray"> ({item.tier_name})</span>}
                    <span className="text-neutral-gray"> x{item.quantity}</span>
                  </div>
                  <span className="font-semibold text-navy-800">{formatPrice(item.line_total)}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-gray-100 pt-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-neutral-gray">Subtotal</span>
                <span className="font-semibold text-navy-800">{formatPrice(order.subtotal)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-neutral-gray">Tax</span>
                <span className="font-semibold text-navy-800">{formatPrice(order.tax)}</span>
              </div>
              {order.discount > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-green-600">Discount</span>
                  <span className="font-semibold text-green-600">-{formatPrice(order.discount)}</span>
                </div>
              )}
              <div className="flex justify-between font-heading font-bold text-lg pt-2 border-t border-gray-100">
                <span className="text-navy-800">Total</span>
                <span className="text-navy-800">{formatPrice(order.total)}</span>
              </div>
            </div>
          </div>

          {/* Customer Info */}
          <div className="card p-6 mb-6">
            <h2 className="font-heading font-bold text-xl text-navy-800 mb-4">Customer Information</h2>
            <div className="grid sm:grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-neutral-gray">Name</span>
                <p className="font-semibold text-navy-800">{order.customer_name}</p>
              </div>
              <div>
                <span className="text-neutral-gray">Email</span>
                <p className="font-semibold text-navy-800">{order.customer_email}</p>
              </div>
              <div>
                <span className="text-neutral-gray">Phone</span>
                <p className="font-semibold text-navy-800">{order.customer_phone}</p>
              </div>
              <div>
                <span className="text-neutral-gray">Payment Method</span>
                <p className="font-semibold text-navy-800 capitalize">{order.payment_method?.replace('_', ' ')}</p>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button onClick={downloadInvoice} className="btn-primary group">
              <Download className="w-4 h-4 group-hover:scale-110 transition-transform" />
              Download Invoice
            </button>
            <Link to="/dashboard" className="btn-secondary">
              View My Orders
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link to="/services" className="btn-accent">
              Continue Shopping
            </Link>
          </div>

          <div className="text-center mt-8 text-sm text-neutral-gray flex items-center justify-center gap-2">
            <Mail className="w-4 h-4" />
            A confirmation email has been sent to {order.customer_email}
          </div>
        </div>
      </div>
    </div>
  );
}
