import { Link } from 'react-router-dom';
import { ArrowRight, Briefcase, Palette, Megaphone, Camera, Eye, Users, Sparkles, TrendingUp, Quote } from 'lucide-react';
import { useProducts, useHeroSettings } from '../hooks/useData';
import { formatPrice } from '../lib/utils';

const categoryIcons: Record<string, typeof Briefcase> = {
  Consulting: Briefcase,
  Branding: Palette,
  Marketing: Megaphone,
  Creative: Camera,
};

const partners = ['UMKM Jakarta', 'Campus Hub', 'Student Union', 'Local Brands ID', 'Creative Community'];

export default function HomePage() {
  const { products, loading } = useProducts();
  const { hero } = useHeroSettings();

  const heroImage = hero?.background_image_url || 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=1920';
  const heroHeadline = hero?.headline || 'Building Future Founders Through Business & Marketing Ecosystem';
  const heroSubheadline = hero?.subheadline || 'A student-driven creative agency ecosystem offering professional consulting, branding, marketing, and content production services.';

  return (
    <div>
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src={heroImage}
            alt="Student entrepreneurs collaborating in a modern workspace"
            className="w-full h-full object-cover"
            loading="eager"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-navy-900/90 via-navy-800/80 to-navy-800/60" />
          <div className="absolute inset-0 bg-gradient-to-t from-navy-900/80 via-transparent to-navy-900/40" />
          <div className="absolute inset-0 dotted-pattern opacity-30" />
        </div>

        <div className="container-max px-4 sm:px-6 lg:px-8 relative z-10 pt-20">
          <div className="max-w-3xl animate-fade-in-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full border border-white/20 mb-6">
              <Sparkles className="w-4 h-4 text-white" />
              <span className="text-white text-sm font-medium">Student-Driven, Agency-Grade</span>
            </div>
            <h1 className="font-heading font-extrabold text-4xl sm:text-5xl lg:text-6xl text-white leading-tight mb-6">
              {heroHeadline.split(' ').slice(0, -3).join(' ')}{' '}
              <span className="text-gradient">{heroHeadline.split(' ').slice(-3).join(' ')}</span>
            </h1>
            <p className="text-lg text-navy-100 mb-8 max-w-2xl leading-relaxed">
              {heroSubheadline}
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/services" className="btn-primary group">
                Explore Our Services
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link to="/about" className="inline-flex items-center justify-center gap-2 px-6 py-3 border-2 border-white text-white font-semibold rounded-lg transition-all duration-200 hover:bg-white hover:text-navy-800">
                Learn More
              </Link>
            </div>
          </div>
        </div>

      </section>

      {/* Services Section */}
      <section className="section-padding bg-neutral-light">
        <div className="container-max">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-sm font-semibold text-navy-500 uppercase tracking-wider">Our Services</span>
            <h2 className="font-heading font-extrabold text-3xl lg:text-4xl text-navy-800 mt-2 mb-4">
              Professional Services for Growing Brands
            </h2>
            <p className="text-neutral-gray">
              From strategy to execution, we help student UMKM and local businesses build, brand, and grow.
            </p>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="card h-96 animate-pulse bg-gray-100" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => {
                const Icon = categoryIcons[product.category || ''] || Briefcase;
                return (
                  <Link
                    key={product.id}
                    to={`/services/${product.slug}`}
                    className="card card-hover overflow-hidden group"
                  >
                    <div className="relative h-48 overflow-hidden">
                      <img
                        src={product.image_url || ''}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        loading="lazy"
                      />
                      <div className="absolute top-4 left-4">
                        <div className="bg-white rounded-full p-2.5 shadow-md">
                          <Icon className="w-5 h-5 text-navy-800" />
                        </div>
                      </div>
                      {product.billing_type === 'recurring' && (
                        <div className="absolute top-4 right-4 bg-navy-800 text-white text-xs font-semibold px-3 py-1 rounded-full">
                          Subscription
                        </div>
                      )}
                    </div>
                    <div className="p-6">
                      <h3 className="font-heading font-bold text-lg text-navy-800 mb-2 group-hover:text-navy-500 transition-colors">
                        {product.name}
                      </h3>
                      <p className="text-neutral-gray text-sm leading-relaxed mb-4 line-clamp-2">
                        {product.tagline}
                      </p>
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-xs text-neutral-gray">Starting from</span>
                          <div className="font-heading font-bold text-navy-800">
                            {formatPrice(product.starting_price)}
                          </div>
                        </div>
                        <ArrowRight className="w-5 h-5 text-navy-400 group-hover:text-navy-800 group-hover:translate-x-1 transition-all" />
                      </div>
                    </div>
                  </Link>
                );
              })}
              <Link to="/services" className="card card-hover flex flex-col items-center justify-center p-8 group border-2 border-dashed border-gray-200 hover:border-navy-400">
                <div className="bg-navy-800 rounded-full p-4 mb-4 group-hover:scale-110 transition-transform">
                  <ArrowRight className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-heading font-bold text-lg text-navy-800">View All Services</h3>
                <p className="text-neutral-gray text-sm mt-1 text-center">See our full catalog of professional services</p>
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Social Proof / Partners */}
      <section className="bg-white py-16">
        <div className="container-max px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="font-heading font-bold text-2xl text-navy-800 mb-2">Trusted by UMKM & Communities</h2>
            <p className="text-neutral-gray text-sm">We are proud to partner with local businesses and student communities</p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-8 lg:gap-12">
            {partners.map((partner) => (
              <div key={partner} className="flex items-center gap-2 text-navy-300 hover:text-navy-500 transition-colors">
                <div className="w-10 h-10 bg-navy-100 rounded-lg flex items-center justify-center">
                  <Users className="w-5 h-5" />
                </div>
                <span className="font-heading font-bold text-sm lg:text-base">{partner}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="bg-navy-800 section-padding relative overflow-hidden">
        <div className="absolute inset-0 dotted-pattern opacity-20" />
        <div className="container-max relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-sm font-semibold text-navy-200 uppercase tracking-wider">Our Mission</span>
              <h2 className="font-heading font-extrabold text-3xl lg:text-4xl text-white mt-2 mb-6">
                Bridging the Gap Between Theory and Practice
              </h2>
              <p className="text-navy-100 text-lg leading-relaxed mb-6">
                Students know the theory, but lack the practice. The Founder Project solves this by creating a collaborative space where students apply their knowledge to real business challenges — helping UMKM grow while building their own skills.
              </p>
              <p className="text-navy-200 leading-relaxed mb-8">
                We are a community of student creators, marketers, and consultants who believe that the best way to learn is by doing. Every project we take on is an opportunity for our members to grow while delivering real value to our clients.
              </p>
              <Link to="/about" className="btn-accent group">
                Learn About Us
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: TrendingUp, title: 'Real Growth', desc: 'Measurable results for every client we work with.' },
                { icon: Users, title: 'Community First', desc: 'A supportive network of student professionals.' },
                { icon: Eye, title: 'Hands-On Learning', desc: 'Practical experience that textbooks cannot teach.' },
                { icon: Sparkles, title: 'Creative Solutions', desc: 'Fresh perspectives from the next generation.' },
              ].map((item) => (
                <div key={item.title} className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 hover:bg-white/10 transition-colors">
                  <div className="bg-white/10 rounded-xl p-3 w-fit mb-4">
                    <item.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-heading font-bold text-white mb-2">{item.title}</h3>
                  <p className="text-navy-200 text-sm leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial */}
      <section className="section-padding bg-neutral-light">
        <div className="container-max">
          <div className="max-w-3xl mx-auto text-center">
            <Quote className="w-12 h-12 text-navy-300 mx-auto mb-6" />
            <blockquote className="font-heading text-2xl lg:text-3xl text-navy-800 font-bold leading-relaxed mb-6">
              "Working with The Founder Project transformed our brand. They took our small UMKM and gave it a professional identity that helped us reach new customers."
            </blockquote>
            <div className="flex items-center justify-center gap-3">
              <div className="w-12 h-12 bg-navy-200 rounded-full flex items-center justify-center">
                <Users className="w-6 h-6 text-navy-800" />
              </div>
              <div className="text-left">
                <div className="font-heading font-bold text-navy-800">Local UMKM Owner</div>
                <div className="text-neutral-gray text-sm">Jakarta, Indonesia</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-navy-800 py-20">
        <div className="container-max px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-heading font-extrabold text-3xl lg:text-4xl text-white mb-4">
            Ready to Build Your Brand?
          </h2>
          <p className="text-navy-200 text-lg mb-8 max-w-2xl mx-auto">
            Whether you need consulting, branding, marketing, or content — we have a service that fits your needs and budget.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/services" className="btn-accent group">
              Browse Services
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link to="/contact" className="inline-flex items-center justify-center gap-2 px-6 py-3 border-2 border-white text-white font-semibold rounded-lg transition-all duration-200 hover:bg-white hover:text-navy-800">
              Get in Touch
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
