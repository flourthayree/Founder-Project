import { Link } from 'react-router-dom';
import { ArrowRight, Calendar, User } from 'lucide-react';
import { useBlogPosts } from '../hooks/useData';
import { formatDate } from '../lib/utils';

export default function BlogPage() {
  const { posts, loading } = useBlogPosts();
  const featured = posts[0];
  const rest = posts.slice(1);

  return (
    <div>
      <section className="bg-navy-800 pt-32 pb-16 relative overflow-hidden">
        <div className="absolute inset-0 dotted-pattern opacity-20" />
        <div className="container-max px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <h1 className="font-heading font-extrabold text-4xl lg:text-5xl text-white mb-4">Blog & Educational Content</h1>
          <p className="text-navy-200 text-lg max-w-2xl mx-auto">
            Insights on business, marketing, branding, entrepreneurship, and the creative industry — from our student community.
          </p>
        </div>
      </section>

      <section className="section-padding bg-neutral-light">
        <div className="container-max">
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="card h-80 animate-pulse bg-gray-100" />
              ))}
            </div>
          ) : (
            <>
              {/* Featured Post */}
              {featured && (
                <Link to={`/blog/${featured.slug}`} className="card card-hover overflow-hidden mb-8 grid md:grid-cols-2 group">
                  <div className="relative h-64 md:h-full overflow-hidden">
                    <img src={featured.image_url || ''} alt={featured.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  </div>
                  <div className="p-8 flex flex-col justify-center">
                    <span className="text-xs font-semibold text-navy-500 uppercase tracking-wider mb-2">Featured</span>
                    <h2 className="font-heading font-extrabold text-2xl lg:text-3xl text-navy-800 mb-3 group-hover:text-navy-500 transition-colors">
                      {featured.title}
                    </h2>
                    <p className="text-neutral-gray leading-relaxed mb-4">{featured.excerpt}</p>
                    <div className="flex items-center gap-4 text-sm text-neutral-gray">
                      <span className="flex items-center gap-1.5"><User className="w-4 h-4" /> {featured.author}</span>
                      <span className="flex items-center gap-1.5"><Calendar className="w-4 h-4" /> {featured.published_at ? formatDate(featured.published_at) : ''}</span>
                    </div>
                    <div className="flex items-center gap-2 text-navy-500 font-semibold mt-4 group-hover:text-navy-800 transition-colors">
                      Read Article <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </Link>
              )}

              {/* Rest of Posts */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {rest.map((post) => (
                  <Link key={post.id} to={`/blog/${post.slug}`} className="card card-hover overflow-hidden group">
                    <div className="relative h-48 overflow-hidden">
                      <img src={post.image_url || ''} alt={post.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                      <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1">
                        <span className="text-xs font-semibold text-navy-800">{post.category}</span>
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className="font-heading font-bold text-lg text-navy-800 mb-2 group-hover:text-navy-500 transition-colors line-clamp-2">
                        {post.title}
                      </h3>
                      <p className="text-neutral-gray text-sm leading-relaxed mb-4 line-clamp-2">{post.excerpt}</p>
                      <div className="flex items-center gap-3 text-xs text-neutral-gray">
                        <span className="flex items-center gap-1"><User className="w-3 h-3" /> {post.author}</span>
                        <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {post.published_at ? formatDate(post.published_at) : ''}</span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </>
          )}
        </div>
      </section>
    </div>
  );
}
