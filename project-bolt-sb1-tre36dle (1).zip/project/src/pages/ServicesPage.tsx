import { Link } from 'react-router-dom';
import { ArrowRight, Briefcase, Palette, Megaphone, Camera, Calendar, RefreshCw, CheckCircle } from 'lucide-react';
import { useProducts } from '../hooks/useData';
import { formatPrice } from '../lib/utils';

const categoryIcons: Record<string, typeof Briefcase> = {
  Consulting: Briefcase,
  Branding: Palette,
  Marketing: Megaphone,
  Creative: Camera,
};

export default function ServicesPage() {
  const { products, loading } = useProducts();

  return (
    <div>
      <section className="bg-navy-800 pt-32 pb-16 relative overflow-hidden">
        <div className="absolute inset-0 dotted-pattern opacity-20" />
        <div className="container-max px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <h1 className="font-heading font-extrabold text-4xl lg:text-5xl text-white mb-4">
            Our Services
          </h1>
          <p className="text-navy-200 text-lg max-w-2xl mx-auto">
            Professional consulting, branding, marketing, and creative services for student UMKM, local businesses, and personal brands.
          </p>
        </div>
      </section>

      <section className="section-padding bg-neutral-light">
        <div className="container-max">
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="card h-96 animate-pulse bg-gray-100" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => {
                const Icon = categoryIcons[product.category || ''] || Briefcase;
                return (
                  <div key={product.id} className="card card-hover overflow-hidden flex flex-col">
                    <div className="relative h-52 overflow-hidden">
                      <img
                        src={product.image_url || ''}
                        alt={product.name}
                        className="w-full h-full object-cover"
                        loading="lazy"
                      />
                      <div className="absolute top-4 left-4">
                        <div className="bg-white rounded-full p-2.5 shadow-md">
                          <Icon className="w-5 h-5 text-navy-800" />
                        </div>
                      </div>
                      {product.billing_type === 'recurring' && (
                        <div className="absolute top-4 right-4 bg-navy-800 text-white text-xs font-semibold px-3 py-1 rounded-full flex items-center gap-1">
                          <RefreshCw className="w-3 h-3" /> Subscription
                        </div>
                      )}
                      {product.booking_required && (
                        <div className="absolute top-4 right-4 bg-white text-navy-800 text-xs font-semibold px-3 py-1 rounded-full flex items-center gap-1">
                          <Calendar className="w-3 h-3" /> Booking
                        </div>
                      )}
                    </div>
                    <div className="p-6 flex flex-col flex-1">
                      <span className="text-xs font-semibold text-navy-500 uppercase tracking-wider mb-2">{product.category}</span>
                      <h3 className="font-heading font-bold text-xl text-navy-800 mb-2">{product.name}</h3>
                      <p className="text-neutral-gray text-sm leading-relaxed mb-4 flex-1">{product.tagline}</p>
                      <div className="flex items-center gap-2 mb-4">
                        {product.billing_type === 'recurring' ? (
                          <span className="text-xs text-navy-500 bg-navy-50 px-3 py-1 rounded-full">Monthly retainer</span>
                        ) : (
                          <span className="text-xs text-navy-500 bg-navy-50 px-3 py-1 rounded-full">One-time</span>
                        )}
                        {product.pricing_type === 'tiered' && (
                          <span className="text-xs text-navy-500 bg-navy-50 px-3 py-1 rounded-full">Tiered pricing</span>
                        )}
                      </div>
                      <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                        <div>
                          <span className="text-xs text-neutral-gray">Starting from</span>
                          <div className="font-heading font-bold text-lg text-navy-800">
                            {formatPrice(product.starting_price)}
                          </div>
                        </div>
                        <Link
                          to={`/services/${product.slug}`}
                          className="inline-flex items-center gap-2 px-4 py-2 bg-navy-800 text-white text-sm font-semibold rounded-lg hover:bg-navy-600 transition-colors group"
                        >
                          View Details
                          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                        </Link>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Info banner */}
          <div className="mt-12 card p-8 bg-navy-800 text-white">
            <div className="grid md:grid-cols-3 gap-6">
              <div className="flex items-start gap-3">
                <CheckCircle className="w-6 h-6 text-white flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-heading font-bold mb-1">Mixed Cart Support</h3>
                  <p className="text-navy-200 text-sm">Add one-time purchases and subscriptions to the same cart.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Calendar className="w-6 h-6 text-white flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-heading font-bold mb-1">Easy Booking</h3>
                  <p className="text-navy-200 text-sm">Pick your time slot for session-based services at checkout.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <RefreshCw className="w-6 h-6 text-white flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-heading font-bold mb-1">Manage Subscriptions</h3>
                  <p className="text-navy-200 text-sm">Upgrade, downgrade, or cancel your subscriptions anytime from your dashboard.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
