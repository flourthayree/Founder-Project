import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  CreditCard, Wallet, Building, QrCode, Calendar, Clock,
  Video, Tag, Check, ArrowRight, AlertCircle, User,
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { formatPrice, generateOrderNumber, TIME_SLOTS, getNextSevenDays } from '../lib/utils';
import type { Order, OrderItem, Booking, Subscription } from '../types';

const paymentMethods = [
  { id: 'bank_transfer', label: 'Bank Transfer', icon: Building },
  { id: 'e_wallet', label: 'E-Wallet (GoPay/OVO/DANA)', icon: Wallet },
  { id: 'qris', label: 'QRIS', icon: QrCode },
  { id: 'credit_card', label: 'Credit Card', icon: CreditCard },
];

export default function CheckoutPage() {
  const navigate = useNavigate();
  const { items, subtotal, clearCart } = useCart();
  const { user } = useAuth();

  const [customerName, setCustomerName] = useState(user?.email?.split('@')[0] || '');
  const [customerEmail, setCustomerEmail] = useState(user?.email || '');
  const [customerPhone, setCustomerPhone] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('bank_transfer');
  const [promoCode, setPromoCode] = useState('');
  const [promoApplied, setPromoApplied] = useState<{ code: string; discount: number } | null>(null);
  const [promoError, setPromoError] = useState('');
  const [notes, setNotes] = useState('');
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState('');

  // Booking state for items that need it
  const [bookingOverrides, setBookingOverrides] = useState<Record<string, { date: string; slot: string; mode: 'online' | 'offline' }>>({});
  const days = getNextSevenDays();

  if (items.length === 0) {
    return (
      <div className="pt-32 pb-16 min-h-[60vh] flex items-center">
        <div className="container-max px-4 text-center">
          <h1 className="font-heading font-extrabold text-3xl text-navy-800 mb-3">Your Cart is Empty</h1>
          <p className="text-neutral-gray mb-6">Add some services to your cart before checking out.</p>
          <Link to="/services" className="btn-primary">Browse Services</Link>
        </div>
      </div>
    );
  }

  const tax = subtotal * 0.11;
  const discount = promoApplied?.discount || 0;
  const total = subtotal + tax - discount;

  const needsBookingItems = items.filter((i) => i.bookingRequired && (!i.bookingDate || !i.bookingTimeSlot));

  const applyPromo = async () => {
    setPromoError('');
    if (!promoCode.trim()) return;
    const { data, error } = await supabase
      .from('promo_codes')
      .select('*')
      .eq('code', promoCode.toUpperCase().trim())
      .eq('is_active', true)
      .maybeSingle();

    if (error || !data) {
      setPromoError('Invalid or expired promo code.');
      setPromoApplied(null);
      return;
    }

    if (data.expires_at && new Date(data.expires_at) < new Date()) {
      setPromoError('This promo code has expired.');
      setPromoApplied(null);
      return;
    }

    if (data.max_uses && data.used_count >= data.max_uses) {
      setPromoError('This promo code has reached its usage limit.');
      setPromoApplied(null);
      return;
    }

    let discountAmount = 0;
    if (data.discount_type === 'percentage') {
      discountAmount = (subtotal * data.discount_value) / 100;
    } else {
      discountAmount = data.discount_value;
    }
    setPromoApplied({ code: data.code, discount: discountAmount });
  };

  const handlePlaceOrder = async () => {
    setError('');
    if (!customerName || !customerEmail || !customerPhone) {
      setError('Please fill in all customer information fields.');
      return;
    }

    // Check all booking items have bookings set
    for (const item of items) {
      if (item.bookingRequired) {
        const override = bookingOverrides[item.cartItemId];
        if (!override && (!item.bookingDate || !item.bookingTimeSlot)) {
          setError(`Please select a date and time for ${item.name}.`);
          return;
        }
      }
    }

    if (!user) {
      setError('Please sign in to place your order.');
      return;
    }

    setProcessing(true);

    try {
      const orderNumber = generateOrderNumber();

      // Create order
      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert({
          order_number: orderNumber,
          status: 'confirmed',
          subtotal,
          tax,
          discount,
          total,
          currency: 'IDR',
          customer_name: customerName,
          customer_email: customerEmail,
          customer_phone: customerPhone,
          promo_code: promoApplied?.code || null,
          payment_method: paymentMethod,
          notes,
        })
        .select()
        .single<Order>();

      if (orderError || !order) {
        throw new Error(orderError?.message || 'Failed to create order.');
      }

      // Create order items
      const orderItems: Omit<OrderItem, 'id'>[] = items.map((item) => {
        const booking = bookingOverrides[item.cartItemId];
        return {
          order_id: order.id,
          product_id: item.productId,
          product_name: item.name,
          tier_name: item.tierName,
          quantity: item.quantity,
          unit_price: item.unitPrice,
          line_total: item.unitPrice * item.quantity,
          billing_type: item.billingType,
          booking_date: booking?.date || item.bookingDate,
          booking_time_slot: booking?.slot || item.bookingTimeSlot,
          consultation_mode: booking?.mode || item.consultationMode,
        };
      });

      const { error: itemsError } = await supabase.from('order_items').insert(orderItems);
      if (itemsError) throw itemsError;

      // Create bookings for session-based items
      const bookings: Omit<Booking, 'id' | 'user_id' | 'created_at'>[] = items
        .filter((i) => i.bookingRequired)
        .map((item) => {
          const booking = bookingOverrides[item.cartItemId];
          return {
            order_id: order.id,
            product_id: item.productId,
            booking_date: booking?.date || item.bookingDate!,
            time_slot: booking?.slot || item.bookingTimeSlot!,
            consultation_mode: booking?.mode || item.consultationMode || 'online',
            status: 'confirmed',
            meeting_link: (booking?.mode || item.consultationMode) === 'online'
              ? `https://meet.google.com/fp-${orderNumber.toLowerCase()}`
              : null,
            location: (booking?.mode || item.consultationMode) === 'offline'
              ? 'The Founder Project Studio, Jakarta'
              : null,
            notes: null,
          };
        });

      if (bookings.length > 0) {
        const { error: bookingError } = await supabase.from('bookings').insert(bookings);
        if (bookingError) throw bookingError;
      }

      // Create subscriptions for recurring items
      const subscriptions: Omit<Subscription, 'id' | 'user_id' | 'created_at'>[] = items
        .filter((i) => i.billingType === 'recurring')
        .map((item) => ({
          product_id: item.productId,
          tier_name: item.tierName,
          status: 'active',
          amount: item.unitPrice,
          billing_cycle: 'monthly',
          current_period_start: new Date().toISOString(),
          current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          cancelled_at: null,
        }));

      if (subscriptions.length > 0) {
        const { error: subError } = await supabase.from('subscriptions').insert(subscriptions);
        if (subError) throw subError;
      }

      // Update promo code usage
      if (promoApplied) {
        await supabase
          .from('promo_codes')
          .update({ used_count: supabase.rpc('increment', { row_id: null }) })
          .eq('code', promoApplied.code);
      }

      clearCart();
      navigate(`/order-confirmation/${orderNumber}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to place order. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="pt-32 pb-16 bg-neutral-light min-h-screen">
      <div className="container-max px-4 sm:px-6 lg:px-8">
        <h1 className="font-heading font-extrabold text-3xl text-navy-800 mb-8">Checkout</h1>

        {!user && (
          <div className="card p-4 mb-6 bg-orange-50 border-orange-200 flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0" />
            <p className="text-sm text-orange-800">
              You need to <Link to="/auth" className="font-semibold underline">sign in</Link> to place your order.
            </p>
          </div>
        )}

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left: Forms */}
          <div className="lg:col-span-2 space-y-6">
            {/* Customer Info */}
            <div className="card p-6">
              <h2 className="font-heading font-bold text-xl text-navy-800 mb-4 flex items-center gap-2">
                <User className="w-5 h-5" /> Customer Information
              </h2>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-navy-800 mb-1 block">Full Name</label>
                  <input type="text" value={customerName} onChange={(e) => setCustomerName(e.target.value)} className="input-field" placeholder="Your name" />
                </div>
                <div>
                  <label className="text-sm font-medium text-navy-800 mb-1 block">Phone Number</label>
                  <input type="tel" value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} className="input-field" placeholder="+62 812 3456 7890" />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-navy-800 mb-1 block">Email Address</label>
                  <input type="email" value={customerEmail} onChange={(e) => setCustomerEmail(e.target.value)} className="input-field" placeholder="you@example.com" />
                </div>
              </div>
            </div>

            {/* Booking for items that need it */}
            {needsBookingItems.length > 0 && (
              <div className="card p-6">
                <h2 className="font-heading font-bold text-xl text-navy-800 mb-4 flex items-center gap-2">
                  <Calendar className="w-5 h-5" /> Session Booking
                </h2>
                <p className="text-neutral-gray text-sm mb-4">Please select a date and time for your session-based services.</p>
                <div className="space-y-6">
                  {needsBookingItems.map((item) => (
                    <div key={item.cartItemId} className="border border-gray-200 rounded-xl p-4">
                      <h3 className="font-heading font-bold text-navy-800 mb-3">{item.name}</h3>
                      <div className="grid grid-cols-2 gap-2 mb-3">
                        {days.map((day) => (
                          <button
                            key={day.value}
                            onClick={() => setBookingOverrides((prev) => ({
                              ...prev,
                              [item.cartItemId]: { ...prev[item.cartItemId], date: day.value, slot: prev[item.cartItemId]?.slot || '', mode: prev[item.cartItemId]?.mode || 'online' },
                            }))}
                            className={`p-2.5 rounded-lg border-2 text-sm transition-all ${
                              bookingOverrides[item.cartItemId]?.date === day.value
                                ? 'border-navy-800 bg-navy-800 text-white'
                                : 'border-gray-200 text-navy-800 hover:border-navy-300'
                            }`}
                          >
                            {day.label}
                          </button>
                        ))}
                      </div>
                      {bookingOverrides[item.cartItemId]?.date && (
                        <>
                          <label className="text-sm font-medium text-navy-800 mb-2 block">Time Slot</label>
                          <div className="grid grid-cols-2 gap-2 mb-3">
                            {TIME_SLOTS.map((slot) => (
                              <button
                                key={slot}
                                onClick={() => setBookingOverrides((prev) => ({
                                  ...prev,
                                  [item.cartItemId]: { ...prev[item.cartItemId], slot },
                                }))}
                                className={`p-2 rounded-lg border-2 text-sm transition-all flex items-center gap-1.5 justify-center ${
                                  bookingOverrides[item.cartItemId]?.slot === slot
                                    ? 'border-navy-800 bg-navy-800 text-white'
                                    : 'border-gray-200 text-navy-800 hover:border-navy-300'
                                }`}
                              >
                                <Clock className="w-3.5 h-3.5" /> {slot}
                              </button>
                            ))}
                          </div>
                          <label className="text-sm font-medium text-navy-800 mb-2 block">Consultation Mode</label>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              onClick={() => setBookingOverrides((prev) => ({
                                ...prev,
                                [item.cartItemId]: { ...prev[item.cartItemId], mode: 'online' },
                              }))}
                              className={`p-2.5 rounded-lg border-2 text-sm transition-all flex items-center gap-2 justify-center ${
                                bookingOverrides[item.cartItemId]?.mode === 'online'
                                  ? 'border-navy-800 bg-navy-800 text-white'
                                  : 'border-gray-200 text-navy-800 hover:border-navy-300'
                              }`}
                            >
                              <Video className="w-4 h-4" /> Online
                            </button>
                            <button
                              onClick={() => setBookingOverrides((prev) => ({
                                ...prev,
                                [item.cartItemId]: { ...prev[item.cartItemId], mode: 'offline' },
                              }))}
                              className={`p-2.5 rounded-lg border-2 text-sm transition-all flex items-center gap-2 justify-center ${
                                bookingOverrides[item.cartItemId]?.mode === 'offline'
                                  ? 'border-navy-800 bg-navy-800 text-white'
                                  : 'border-gray-200 text-navy-800 hover:border-navy-300'
                              }`}
                            >
                              <Building className="w-4 h-4" /> In-Studio
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Payment Method */}
            <div className="card p-6">
              <h2 className="font-heading font-bold text-xl text-navy-800 mb-4 flex items-center gap-2">
                <CreditCard className="w-5 h-5" /> Payment Method
              </h2>
              <div className="grid grid-cols-2 gap-3">
                {paymentMethods.map((method) => (
                  <button
                    key={method.id}
                    onClick={() => setPaymentMethod(method.id)}
                    className={`p-4 rounded-xl border-2 transition-all flex items-center gap-3 ${
                      paymentMethod === method.id
                        ? 'border-navy-800 bg-navy-50'
                        : 'border-gray-200 hover:border-navy-300'
                    }`}
                  >
                    <method.icon className={`w-5 h-5 ${paymentMethod === method.id ? 'text-navy-800' : 'text-neutral-gray'}`} />
                    <span className={`text-sm font-medium ${paymentMethod === method.id ? 'text-navy-800' : 'text-neutral-gray'}`}>{method.label}</span>
                  </button>
                ))}
              </div>
              <p className="text-xs text-neutral-gray mt-3">
                This is a simulated payment. No real transaction will be processed.
              </p>
            </div>

            {/* Notes */}
            <div className="card p-6">
              <h2 className="font-heading font-bold text-xl text-navy-800 mb-4">Additional Notes</h2>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="input-field min-h-[100px] resize-y"
                placeholder="Any special requests or information we should know about your order?"
              />
            </div>
          </div>

          {/* Right: Order Summary */}
          <div className="lg:col-span-1">
            <div className="card p-6 sticky top-24">
              <h2 className="font-heading font-bold text-xl text-navy-800 mb-4">Order Summary</h2>

              <div className="space-y-3 mb-4 max-h-64 overflow-y-auto">
                {items.map((item) => (
                  <div key={item.cartItemId} className="flex gap-3">
                    <div className="w-14 h-14 rounded-lg overflow-hidden flex-shrink-0">
                      <img src={item.image_url || ''} alt={item.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-semibold text-navy-800 truncate">{item.name}</h4>
                      {item.tierName && <p className="text-xs text-neutral-gray">{item.tierName}</p>}
                      <p className="text-xs text-neutral-gray">Qty: {item.quantity}</p>
                    </div>
                    <div className="text-sm font-semibold text-navy-800 whitespace-nowrap">
                      {formatPrice(item.unitPrice * item.quantity)}
                    </div>
                  </div>
                ))}
              </div>

              {/* Promo Code */}
              <div className="border-t border-gray-100 pt-4 mb-4">
                <label className="text-sm font-medium text-navy-800 mb-2 block flex items-center gap-2">
                  <Tag className="w-4 h-4" /> Promo Code
                </label>
                {promoApplied ? (
                  <div className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-semibold text-green-800">{promoApplied.code}</span>
                    </div>
                    <span className="text-sm font-semibold text-green-800">-{formatPrice(promoApplied.discount)}</span>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      className="input-field !py-2 text-sm"
                      placeholder="Enter code"
                    />
                    <button onClick={applyPromo} className="px-4 py-2 bg-navy-800 text-white text-sm font-semibold rounded-lg hover:bg-navy-600 transition-colors">
                      Apply
                    </button>
                  </div>
                )}
                {promoError && <p className="text-xs text-red-500 mt-1">{promoError}</p>}
              </div>

              <div className="border-t border-gray-100 pt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-gray">Subtotal</span>
                  <span className="font-semibold text-navy-800">{formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-gray">Tax (11%)</span>
                  <span className="font-semibold text-navy-800">{formatPrice(tax)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-green-600">Discount</span>
                    <span className="font-semibold text-green-600">-{formatPrice(discount)}</span>
                  </div>
                )}
                <div className="flex justify-between font-heading font-bold text-lg pt-2 border-t border-gray-100">
                  <span className="text-navy-800">Total</span>
                  <span className="text-navy-800">{formatPrice(total)}</span>
                </div>
              </div>

              {error && (
                <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-red-800">{error}</p>
                </div>
              )}

              <button
                onClick={handlePlaceOrder}
                disabled={processing || !user}
                className="btn-primary w-full mt-6 group"
              >
                {processing ? (
                  <>Processing...</>
                ) : (
                  <>
                    Place Order
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
