import { Calendar, MapPin, Users, Video, GraduationCap, Handshake, ArrowRight } from 'lucide-react';
import { usePrograms } from '../hooks/useData';
import { formatDate } from '../lib/utils';
import { Link } from 'react-router-dom';

const programTypeIcons: Record<string, typeof Video> = {
  workshop: GraduationCap,
  webinar: Video,
  collaboration: Handshake,
};

const programTypeLabels: Record<string, string> = {
  workshop: 'Workshop',
  webinar: 'Webinar',
  collaboration: 'Collaboration',
};

export default function ProgramsPage() {
  const { programs, loading } = usePrograms();

  return (
    <div>
      <section className="bg-navy-800 pt-32 pb-16 relative overflow-hidden">
        <div className="absolute inset-0 dotted-pattern opacity-20" />
        <div className="container-max px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <h1 className="font-heading font-extrabold text-4xl lg:text-5xl text-white mb-4">Programs & Events</h1>
          <p className="text-navy-200 text-lg max-w-2xl mx-auto">
            Join our workshops, webinars, and community collaborations. Learn, connect, and grow with The Founder Project.
          </p>
        </div>
      </section>

      <section className="section-padding bg-neutral-light">
        <div className="container-max">
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="card h-80 animate-pulse bg-gray-100" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {programs.map((program) => {
                const Icon = programTypeIcons[program.program_type] || Calendar;
                return (
                  <div key={program.id} className="card card-hover overflow-hidden flex flex-col">
                    <div className="relative h-56 overflow-hidden">
                      <img src={program.image_url || ''} alt={program.title} className="w-full h-full object-cover" loading="lazy" />
                      <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1.5 flex items-center gap-1.5">
                        <Icon className="w-4 h-4 text-navy-800" />
                        <span className="text-xs font-semibold text-navy-800">{programTypeLabels[program.program_type] || program.program_type}</span>
                      </div>
                    </div>
                    <div className="p-6 flex flex-col flex-1">
                      <h3 className="font-heading font-bold text-xl text-navy-800 mb-2">{program.title}</h3>
                      <p className="text-neutral-gray text-sm leading-relaxed mb-4 flex-1">{program.description}</p>
                      <div className="space-y-2 mb-4">
                        <div className="flex items-center gap-2 text-sm text-navy-800">
                          <Calendar className="w-4 h-4 text-neutral-gray" />
                          {program.event_date ? formatDate(program.event_date) : 'Date TBA'}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-navy-800">
                          <MapPin className="w-4 h-4 text-neutral-gray" />
                          {program.location || 'Location TBA'}
                        </div>
                        {program.capacity && (
                          <div className="flex items-center gap-2 text-sm text-navy-800">
                            <Users className="w-4 h-4 text-neutral-gray" />
                            {program.capacity} spots
                          </div>
                        )}
                      </div>
                      <Link to="/contact" className="btn-primary w-full group mt-auto">
                        Register Interest
                        <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </Link>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* CTA */}
          <div className="card p-8 bg-navy-800 text-white text-center mt-12">
            <h2 className="font-heading font-extrabold text-2xl mb-3">Want to Collaborate?</h2>
            <p className="text-navy-200 mb-6 max-w-xl mx-auto">
              We are always open to partnerships with UMKM, organizations, and student communities. Let's create something together.
            </p>
            <Link to="/contact" className="btn-accent group">
              Get in Touch
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
