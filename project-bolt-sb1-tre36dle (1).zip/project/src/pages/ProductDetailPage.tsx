import { useParams, useNavigate, Link } from 'react-router-dom';
import { useState } from 'react';
import {
  ArrowLeft, Check, Calendar, RefreshCw, Clock,
  Video, Building, ShoppingCart, Briefcase, Palette, Megaphone, Camera,
} from 'lucide-react';
import { useProduct } from '../hooks/useData';
import { useCart } from '../context/CartContext';
import { formatPrice, TIME_SLOTS, getNextSevenDays } from '../lib/utils';

const categoryIcons: Record<string, typeof Briefcase> = {
  Consulting: Briefcase,
  Branding: Palette,
  Marketing: Megaphone,
  Creative: Camera,
};

export default function ProductDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { product, tiers, loading } = useProduct(slug || '');
  const { addItem } = useCart();

  const [selectedTierId, setSelectedTierId] = useState<string | null>(null);
  const [bookingDate, setBookingDate] = useState<string>('');
  const [bookingTimeSlot, setBookingTimeSlot] = useState<string>('');
  const [consultationMode, setConsultationMode] = useState<'online' | 'offline'>('online');
  const [added, setAdded] = useState(false);

  if (loading) {
    return (
      <div className="pt-32 pb-16">
        <div className="container-max px-4 sm:px-6 lg:px-8">
          <div className="card h-96 animate-pulse bg-gray-100" />
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="pt-32 pb-16 text-center">
        <div className="container-max px-4">
          <h1 className="font-heading font-extrabold text-3xl text-navy-800 mb-4">Service Not Found</h1>
          <p className="text-neutral-gray mb-6">The service you are looking for does not exist or is no longer available.</p>
          <Link to="/services" className="btn-primary">Back to Services</Link>
        </div>
      </div>
    );
  }

  const Icon = categoryIcons[product.category || ''] || Briefcase;
  const days = getNextSevenDays();
  const hasTiers = tiers.length > 0;
  const selectedTier = tiers.find((t) => t.id === selectedTierId);
  const currentPrice = selectedTier ? selectedTier.price : product.starting_price;
  const needsBooking = product.booking_required;

  const canAddToCart = () => {
    if (hasTiers && !selectedTierId) return false;
    if (needsBooking && (!bookingDate || !bookingTimeSlot)) return false;
    return true;
  };

  const handleAddToCart = () => {
    if (!canAddToCart()) return;
    addItem({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      image_url: product.image_url,
      tierName: selectedTier?.tier_name || null,
      tierId: selectedTierId,
      unitPrice: currentPrice,
      quantity: 1,
      billingType: product.billing_type as 'one_time' | 'recurring',
      bookingRequired: needsBooking,
      bookingDate: needsBooking ? bookingDate : null,
      bookingTimeSlot: needsBooking ? bookingTimeSlot : null,
      consultationMode: needsBooking ? consultationMode : null,
    });
    setAdded(true);
    setTimeout(() => setAdded(false), 3000);
  };

  return (
    <div>
      {/* Hero */}
      <section className="bg-navy-800 pt-32 pb-12 relative overflow-hidden">
        <div className="absolute inset-0 dotted-pattern opacity-20" />
        <div className="container-max px-4 sm:px-6 lg:px-8 relative z-10">
          <Link to="/services" className="inline-flex items-center gap-2 text-navy-200 hover:text-white transition-colors mb-6">
            <ArrowLeft className="w-4 h-4" /> Back to Services
          </Link>
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-white rounded-full p-2.5">
              <Icon className="w-6 h-6 text-navy-800" />
            </div>
            <span className="text-navy-200 text-sm font-medium uppercase tracking-wider">{product.category}</span>
          </div>
          <h1 className="font-heading font-extrabold text-3xl lg:text-4xl text-white mb-3">{product.name}</h1>
          <p className="text-navy-200 text-lg max-w-2xl">{product.tagline}</p>
        </div>
      </section>

      <section className="section-padding bg-neutral-light">
        <div className="container-max">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Left: Image + Description */}
            <div>
              <div className="card overflow-hidden rounded-2xl mb-6">
                <img
                  src={product.image_url || ''}
                  alt={product.name}
                  className="w-full h-80 object-cover"
                />
              </div>
              <div className="card p-6">
                <h2 className="font-heading font-bold text-xl text-navy-800 mb-4">About This Service</h2>
                <p className="text-neutral-gray leading-relaxed whitespace-pre-line">{product.description}</p>
              </div>

              {/* Features */}
              <div className="card p-6 mt-6">
                <h3 className="font-heading font-bold text-lg text-navy-800 mb-4">What's Included</h3>
                <ul className="space-y-3">
                  {product.billing_type === 'recurring' && (
                    <li className="flex items-start gap-3">
                      <RefreshCw className="w-5 h-5 text-navy-500 flex-shrink-0 mt-0.5" />
                      <span className="text-navy-800">Monthly subscription with auto-renew. Cancel anytime from your dashboard.</span>
                    </li>
                  )}
                  {product.booking_required && (
                    <li className="flex items-start gap-3">
                      <Calendar className="w-5 h-5 text-navy-500 flex-shrink-0 mt-0.5" />
                      <span className="text-navy-800">Session booking with calendar and time-slot picker.</span>
                    </li>
                  )}
                  <li className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-navy-500 flex-shrink-0 mt-0.5" />
                    <span className="text-navy-800">Professional service delivered by our student team.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-navy-500 flex-shrink-0 mt-0.5" />
                    <span className="text-navy-800">Quality guaranteed — we hold ourselves to agency-grade standards.</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Right: Pricing + Booking + Add to Cart */}
            <div>
              <div className="card p-6 lg:p-8 sticky top-24">
                <div className="mb-6">
                  <span className="text-sm text-neutral-gray">
                    {hasTiers ? 'Choose a package' : 'Price'}
                  </span>
                  <div className="font-heading font-extrabold text-3xl text-navy-800 mt-1">
                    {formatPrice(currentPrice)}
                    {product.billing_type === 'recurring' && (
                      <span className="text-base font-normal text-neutral-gray">/month</span>
                    )}
                  </div>
                </div>

                {/* Tier Selection */}
                {hasTiers && (
                  <div className="space-y-3 mb-6">
                    {tiers.map((tier) => (
                      <button
                        key={tier.id}
                        onClick={() => setSelectedTierId(tier.id)}
                        className={`w-full text-left p-4 rounded-xl border-2 transition-all ${
                          selectedTierId === tier.id
                            ? 'border-navy-800 bg-navy-50'
                            : 'border-gray-200 hover:border-navy-300'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-heading font-bold text-navy-800">{tier.tier_name}</span>
                          <span className="font-heading font-bold text-navy-800">{formatPrice(tier.price)}</span>
                        </div>
                        {tier.description && (
                          <p className="text-neutral-gray text-sm mb-2">{tier.description}</p>
                        )}
                        {tier.features && tier.features.length > 0 && (
                          <ul className="space-y-1 mt-2">
                            {tier.features.map((feature, i) => (
                              <li key={i} className="flex items-start gap-2 text-sm text-navy-800">
                                <Check className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                                {feature}
                              </li>
                            ))}
                          </ul>
                        )}
                      </button>
                    ))}
                  </div>
                )}

                {/* Booking Section */}
                {needsBooking && (
                  <div className="mb-6">
                    <h3 className="font-heading font-bold text-navy-800 mb-3 flex items-center gap-2">
                      <Calendar className="w-5 h-5" /> Select Date & Time
                    </h3>
                    <div className="grid grid-cols-2 gap-2 mb-4">
                      {days.map((day) => (
                        <button
                          key={day.value}
                          onClick={() => setBookingDate(day.value)}
                          className={`p-3 rounded-lg border-2 text-sm transition-all ${
                            bookingDate === day.value
                              ? 'border-navy-800 bg-navy-800 text-white'
                              : 'border-gray-200 text-navy-800 hover:border-navy-300'
                          }`}
                        >
                          {day.label}
                        </button>
                      ))}
                    </div>
                    {bookingDate && (
                      <div className="mb-4">
                        <label className="text-sm font-medium text-navy-800 mb-2 block">Time Slot</label>
                        <div className="grid grid-cols-2 gap-2">
                          {TIME_SLOTS.map((slot) => (
                            <button
                              key={slot}
                              onClick={() => setBookingTimeSlot(slot)}
                              className={`p-2 rounded-lg border-2 text-sm transition-all flex items-center gap-1.5 justify-center ${
                                bookingTimeSlot === slot
                                  ? 'border-navy-800 bg-navy-800 text-white'
                                  : 'border-gray-200 text-navy-800 hover:border-navy-300'
                              }`}
                            >
                              <Clock className="w-3.5 h-3.5" />
                              {slot}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                    <div className="mb-4">
                      <label className="text-sm font-medium text-navy-800 mb-2 block">Consultation Mode</label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => setConsultationMode('online')}
                          className={`p-3 rounded-lg border-2 text-sm transition-all flex items-center gap-2 justify-center ${
                            consultationMode === 'online'
                              ? 'border-navy-800 bg-navy-800 text-white'
                              : 'border-gray-200 text-navy-800 hover:border-navy-300'
                          }`}
                        >
                          <Video className="w-4 h-4" /> Online
                        </button>
                        <button
                          onClick={() => setConsultationMode('offline')}
                          className={`p-3 rounded-lg border-2 text-sm transition-all flex items-center gap-2 justify-center ${
                            consultationMode === 'offline'
                              ? 'border-navy-800 bg-navy-800 text-white'
                              : 'border-gray-200 text-navy-800 hover:border-navy-300'
                          }`}
                        >
                          <Building className="w-4 h-4" /> In-Studio
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Validation message */}
                {hasTiers && !selectedTierId && (
                  <p className="text-sm text-orange-600 mb-3">Please select a package to continue.</p>
                )}
                {needsBooking && !bookingDate && (
                  <p className="text-sm text-orange-600 mb-3">Please select a date for your session.</p>
                )}
                {needsBooking && bookingDate && !bookingTimeSlot && (
                  <p className="text-sm text-orange-600 mb-3">Please select a time slot.</p>
                )}

                {/* Add to Cart */}
                <button
                  onClick={handleAddToCart}
                  disabled={!canAddToCart()}
                  className="btn-primary w-full mb-3"
                >
                  {added ? (
                    <><Check className="w-5 h-5" /> Added to Cart!</>
                  ) : (
                    <><ShoppingCart className="w-5 h-5" /> Add to Cart</>
                  )}
                </button>
                <button
                  onClick={() => {
                    if (canAddToCart()) {
                      handleAddToCart();
                      navigate('/cart');
                    }
                  }}
                  disabled={!canAddToCart()}
                  className="btn-secondary w-full"
                >
                  Buy Now
                </button>

                {/* Trust badges */}
                <div className="mt-6 pt-6 border-t border-gray-100 space-y-2">
                  <div className="flex items-center gap-2 text-sm text-neutral-gray">
                    <Check className="w-4 h-4 text-green-600" /> No hidden fees
                  </div>
                  <div className="flex items-center gap-2 text-sm text-neutral-gray">
                    <Check className="w-4 h-4 text-green-600" /> Professional student team
                  </div>
                  {product.billing_type === 'recurring' && (
                    <div className="flex items-center gap-2 text-sm text-neutral-gray">
                      <Check className="w-4 h-4 text-green-600" /> Cancel anytime
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
