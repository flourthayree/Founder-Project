import { Link } from 'react-router-dom';
import {
  Lightbulb, Users, TrendingUp, Award, Target,
  BookOpen, Film, GraduationCap, Megaphone, Handshake,
  ArrowRight, Rocket, Heart, Zap, Shield,
} from 'lucide-react';
import { useTeamMembers } from '../hooks/useData';

const vision = 'To become a leading ecosystem that connects students, UMKM, and creative talents — transforming ideas into real business impact through collaboration, education, and professional-grade creative services.';

const missions = [
  'Provide a platform for students to apply business and marketing knowledge in real-world projects.',
  'Support UMKM and personal brands with affordable, professional consulting and creative services.',
  'Build a collaborative community where students learn by doing and grow together.',
  'Deliver consistent, high-quality educational content on business, marketing, and entrepreneurship.',
  'Create meaningful partnerships between students, communities, and local businesses.',
];

const goals = [
  'Establish The Founder Project as a trusted, go-to creative and consulting agency for student and local UMKM.',
  'Help at least 50 UMKM improve their branding and digital presence each year.',
  'Produce consistent educational content that reaches and benefits the student community.',
  'Develop a sustainable, student-run business model that creates real value and revenue.',
  'Build a strong network of alumni, mentors, and industry partners for ongoing support.',
];

const coreValues = [
  { icon: Lightbulb, title: 'Innovation', desc: 'We embrace new ideas and creative approaches to solve real business problems.' },
  { icon: Users, title: 'Collaboration', desc: 'We believe the best results come from working together — students, clients, and community.' },
  { icon: TrendingUp, title: 'Growth', desc: 'We are committed to continuous learning and helping others grow alongside us.' },
  { icon: Award, title: 'Professionalism', desc: 'Student-run, but agency-grade. We hold ourselves to professional standards in everything we do.' },
  { icon: Heart, title: 'Impact', desc: 'Every project we take on should create real, measurable value for our clients and community.' },
];

const focusAreas = [
  { icon: Rocket, title: 'Business Development', desc: 'Helping UMKM build sustainable business models and growth strategies.' },
  { icon: Megaphone, title: 'Digital Marketing', desc: 'Managing social media, content, and ad campaigns for consistent digital presence.' },
  { icon: Film, title: 'Creative Media', desc: 'Producing professional photos, videos, and design that tell compelling brand stories.' },
  { icon: Shield, title: 'Personal Branding', desc: 'Building individual brands for students and young professionals.' },
  { icon: Target, title: 'Business Consultation', desc: 'Providing expert advice on business models, strategy, and growth.' },
];

const mainPrograms = [
  { icon: BookOpen, title: 'Educational Content', desc: 'Articles, guides, and resources on business, marketing, and entrepreneurship.' },
  { icon: Film, title: 'Creative Project', desc: 'Real client projects in branding, content production, and digital marketing.' },
  { icon: GraduationCap, title: 'Workshop & Webinar', desc: 'Hands-on sessions on branding, marketing, content creation, and business strategy.' },
  { icon: Megaphone, title: 'Marketing Consultation', desc: 'One-on-one and group consultations for UMKM and personal brands.' },
  { icon: Handshake, title: 'Community Collaboration', desc: 'Partnerships with UMKM, organizations, and student communities.' },
];

const targetAudience = [
  'Business & Marketing Students',
  'Creative & Media Students',
  'Student-Run UMKM',
  'Beginner Personal Brands',
  'Young People Interested in Digital Business',
];

const impacts = [
  { title: 'Active Community', desc: 'A growing community of student creators, marketers, and consultants.' },
  { title: 'Consistent Content', desc: 'Regular educational content that reaches and benefits the student ecosystem.' },
  { title: 'Improved Member Skills', desc: 'Members gain real-world experience that accelerates their professional growth.' },
  { title: 'Strong Networking', desc: 'Connections with UMKM, industry partners, and fellow student founders.' },
  { title: 'Established Services', desc: 'Professional creative and marketing services that deliver real client results.' },
];

export default function AboutPage() {
  const { members, loading } = useTeamMembers();

  return (
    <div>
      {/* Hero */}
      <section className="bg-navy-800 pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 dotted-pattern opacity-20" />
        <div className="container-max px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full border border-white/20 mb-6">
            <Users className="w-4 h-4 text-white" />
            <span className="text-white text-sm font-medium">About The Founder Project</span>
          </div>
          <h1 className="font-heading font-extrabold text-4xl lg:text-5xl text-white mb-6 max-w-3xl mx-auto">
            Building Future Founders Through Business & Marketing Ecosystem
          </h1>
          <p className="text-navy-200 text-lg max-w-2xl mx-auto">
            A student-driven creative agency ecosystem where theory meets practice, and ideas become impact.
          </p>
        </div>
      </section>

      {/* Background */}
      <section className="section-padding bg-white">
        <div className="container-max">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-sm font-semibold text-navy-500 uppercase tracking-wider">The Problem</span>
              <h2 className="font-heading font-extrabold text-3xl text-navy-800 mt-2 mb-4">
                Students Know Theory, But Lack Practice
              </h2>
              <p className="text-neutral-gray text-lg leading-relaxed mb-4">
                Business and marketing students spend years learning theory — business models, marketing strategies, brand frameworks. But when it comes to applying that knowledge in real situations, there is a gap.
              </p>
              <p className="text-neutral-gray leading-relaxed">
                At the same time, many UMKM and local businesses need affordable, professional help with branding, marketing, and strategy — but cannot afford traditional agency rates.
              </p>
            </div>
            <div className="bg-navy-800 rounded-3xl p-8 lg:p-10 text-white relative overflow-hidden">
              <div className="absolute inset-0 dotted-pattern opacity-20" />
              <div className="relative z-10">
                <span className="text-sm font-semibold text-navy-200 uppercase tracking-wider">Our Solution</span>
                <h3 className="font-heading font-extrabold text-2xl mt-2 mb-4">
                  The Founder Project Connects Them
                </h3>
                <p className="text-navy-100 leading-relaxed mb-6">
                  We create a space where students apply their knowledge to real business challenges — helping UMKM grow while building their own skills, portfolios, and professional networks.
                </p>
                <div className="flex items-center gap-3 text-navy-200">
                  <Zap className="w-5 h-5" />
                  <span className="text-sm">Learning by doing, growing by helping.</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About */}
      <section className="section-padding bg-neutral-light">
        <div className="container-max max-w-4xl">
          <div className="text-center mb-8">
            <span className="text-sm font-semibold text-navy-500 uppercase tracking-wider">About Us</span>
            <h2 className="font-heading font-extrabold text-3xl text-navy-800 mt-2">
              A Community of Student Creators
            </h2>
          </div>
          <p className="text-neutral-gray text-lg leading-relaxed text-center">
            The Founder Project is a student-driven creative ecosystem and community that also operates as a business consulting, branding, marketing, and creative production agency. We bring together students from management, marketing, design, and media to collaborate on real projects for real clients — creating a space where everyone grows together.
          </p>
        </div>
      </section>

      {/* Vision */}
      <section className="bg-navy-800 py-20 relative overflow-hidden">
        <div className="absolute inset-0 dotted-pattern opacity-20" />
        <div className="container-max relative z-10 text-center">
          <span className="text-sm font-semibold text-navy-200 uppercase tracking-wider">Our Vision</span>
          <p className="font-heading font-extrabold text-2xl lg:text-4xl text-white mt-4 max-w-4xl mx-auto leading-tight">
            {vision}
          </p>
        </div>
      </section>

      {/* Mission */}
      <section className="section-padding bg-white">
        <div className="container-max">
          <div className="text-center mb-12">
            <span className="text-sm font-semibold text-navy-500 uppercase tracking-wider">Our Mission</span>
            <h2 className="font-heading font-extrabold text-3xl text-navy-800 mt-2">What Drives Us</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {missions.map((mission, i) => (
              <div key={i} className="card p-6 flex gap-4">
                <div className="flex-shrink-0 w-10 h-10 bg-navy-800 text-white rounded-full flex items-center justify-center font-heading font-bold">
                  {i + 1}
                </div>
                <p className="text-navy-800 leading-relaxed pt-1">{mission}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Goals */}
      <section className="section-padding bg-neutral-light">
        <div className="container-max">
          <div className="text-center mb-12">
            <span className="text-sm font-semibold text-navy-500 uppercase tracking-wider">Our Goals</span>
            <h2 className="font-heading font-extrabold text-3xl text-navy-800 mt-2">What We Aim to Achieve</h2>
          </div>
          <div className="max-w-4xl mx-auto">
            <div className="card p-8 mb-6 bg-navy-800 text-white">
              <h3 className="font-heading font-bold text-xl mb-2">General Goal</h3>
              <p className="text-navy-100 leading-relaxed">
                To build a sustainable, student-run ecosystem that delivers professional creative and consulting services while developing the next generation of founders, marketers, and creators.
              </p>
            </div>
            <div className="space-y-4">
              {goals.map((goal, i) => (
                <div key={i} className="card p-6 flex items-start gap-4">
                  <Target className="w-6 h-6 text-navy-500 flex-shrink-0 mt-0.5" />
                  <p className="text-navy-800 leading-relaxed">{goal}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="section-padding bg-white">
        <div className="container-max">
          <div className="text-center mb-12">
            <span className="text-sm font-semibold text-navy-500 uppercase tracking-wider">Core Values</span>
            <h2 className="font-heading font-extrabold text-3xl text-navy-800 mt-2">What We Stand For</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-6">
            {coreValues.map((value) => (
              <div key={value.title} className="card card-hover p-6 text-center">
                <div className="bg-navy-100 rounded-2xl p-4 w-fit mx-auto mb-4">
                  <value.icon className="w-8 h-8 text-navy-800" />
                </div>
                <h3 className="font-heading font-bold text-lg text-navy-800 mb-2">{value.title}</h3>
                <p className="text-neutral-gray text-sm leading-relaxed">{value.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Focus Areas */}
      <section className="section-padding bg-neutral-light">
        <div className="container-max">
          <div className="text-center mb-12">
            <span className="text-sm font-semibold text-navy-500 uppercase tracking-wider">Focus Areas</span>
            <h2 className="font-heading font-extrabold text-3xl text-navy-800 mt-2">What We Do</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {focusAreas.map((area) => (
              <div key={area.title} className="card card-hover p-6 flex gap-4">
                <div className="bg-navy-800 rounded-xl p-3 flex-shrink-0">
                  <area.icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-heading font-bold text-lg text-navy-800 mb-1">{area.title}</h3>
                  <p className="text-neutral-gray text-sm leading-relaxed">{area.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Main Programs */}
      <section className="section-padding bg-white">
        <div className="container-max">
          <div className="text-center mb-12">
            <span className="text-sm font-semibold text-navy-500 uppercase tracking-wider">Main Programs</span>
            <h2 className="font-heading font-extrabold text-3xl text-navy-800 mt-2">How We Operate</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {mainPrograms.map((program) => (
              <div key={program.title} className="card card-hover p-6">
                <div className="bg-navy-100 rounded-2xl p-4 w-fit mb-4">
                  <program.icon className="w-7 h-7 text-navy-800" />
                </div>
                <h3 className="font-heading font-bold text-lg text-navy-800 mb-2">{program.title}</h3>
                <p className="text-neutral-gray text-sm leading-relaxed">{program.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Target Audience */}
      <section className="section-padding bg-navy-800 relative overflow-hidden">
        <div className="absolute inset-0 dotted-pattern opacity-20" />
        <div className="container-max relative z-10">
          <div className="text-center mb-12">
            <span className="text-sm font-semibold text-navy-200 uppercase tracking-wider">Target Audience</span>
            <h2 className="font-heading font-extrabold text-3xl text-white mt-2">Who We Serve</h2>
          </div>
          <div className="flex flex-wrap justify-center gap-4 max-w-4xl mx-auto">
            {targetAudience.map((audience) => (
              <div key={audience} className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-6 py-3 text-white font-medium hover:bg-white/20 transition-colors">
                {audience}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Meet the Team */}
      <section className="section-padding bg-white">
        <div className="container-max">
          <div className="text-center mb-12">
            <span className="text-sm font-semibold text-navy-500 uppercase tracking-wider">Meet the Team</span>
            <h2 className="font-heading font-extrabold text-3xl text-navy-800 mt-2">The People Behind The Project</h2>
          </div>
          {loading ? (
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {[...Array(2)].map((_, i) => (
                <div key={i} className="card h-96 animate-pulse bg-gray-100" />
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {members.map((member) => (
                <div key={member.id} className="card card-hover overflow-hidden">
                  <div className="relative h-72 overflow-hidden">
                    <img
                      src={member.photo_url || ''}
                      alt={member.full_name}
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-navy-900/60 to-transparent" />
                    <div className="absolute bottom-4 left-6">
                      <h3 className="font-heading font-extrabold text-2xl text-white">{member.full_name}</h3>
                    </div>
                  </div>
                  <div className="p-6">
                    <p className="text-neutral-gray leading-relaxed text-sm">{member.bio}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Impact */}
      <section className="section-padding bg-neutral-light">
        <div className="container-max">
          <div className="text-center mb-12">
            <span className="text-sm font-semibold text-navy-500 uppercase tracking-wider">Our Impact</span>
            <h2 className="font-heading font-extrabold text-3xl text-navy-800 mt-2">What We Have Achieved</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {impacts.map((impact) => (
              <div key={impact.title} className="card p-6 flex gap-4">
                <div className="bg-green-100 rounded-xl p-3 flex-shrink-0">
                  <TrendingUp className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-heading font-bold text-navy-800 mb-1">{impact.title}</h3>
                  <p className="text-neutral-gray text-sm leading-relaxed">{impact.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-navy-800 py-20 relative overflow-hidden">
        <div className="absolute inset-0 dotted-pattern opacity-20" />
        <div className="container-max relative z-10 text-center">
          <h2 className="font-heading font-extrabold text-3xl lg:text-4xl text-white mb-4">
            Want to Work With Us?
          </h2>
          <p className="text-navy-200 text-lg mb-8 max-w-2xl mx-auto">
            Whether you need professional services or want to join our community, we would love to hear from you.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/services" className="btn-accent group">
              Explore Our Services
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link to="/contact" className="inline-flex items-center justify-center gap-2 px-6 py-3 border-2 border-white text-white font-semibold rounded-lg transition-all duration-200 hover:bg-white hover:text-navy-800">
              Join the Community
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
