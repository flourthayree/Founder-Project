import { Link } from 'react-router-dom';
import { Trash2, Minus, Plus, ShoppingCart, ArrowRight, RefreshCw, Calendar, Video, Building } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { formatPrice } from '../lib/utils';

export default function CartPage() {
  const { items, removeItem, updateQuantity, subtotal, oneTimeSubtotal, recurringSubtotal, itemCount } = useCart();

  if (items.length === 0) {
    return (
      <div className="pt-32 pb-16 min-h-[60vh] flex items-center">
        <div className="container-max px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-navy-100 rounded-full p-6 w-fit mx-auto mb-6">
            <ShoppingCart className="w-12 h-12 text-navy-800" />
          </div>
          <h1 className="font-heading font-extrabold text-3xl text-navy-800 mb-3">Your Cart is Empty</h1>
          <p className="text-neutral-gray mb-8 max-w-md mx-auto">
            Browse our services and add the ones that fit your needs. We offer consulting, branding, marketing, and creative production.
          </p>
          <Link to="/services" className="btn-primary group">
            Explore Services
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-16 bg-neutral-light min-h-screen">
      <div className="container-max px-4 sm:px-6 lg:px-8">
        <h1 className="font-heading font-extrabold text-3xl text-navy-800 mb-2">Shopping Cart</h1>
        <p className="text-neutral-gray mb-8">{itemCount} {itemCount === 1 ? 'item' : 'items'} in your cart</p>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item) => (
              <div key={item.cartItemId} className="card p-4 sm:p-6">
                <div className="flex gap-4">
                  <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-xl overflow-hidden flex-shrink-0">
                    <img src={item.image_url || ''} alt={item.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="font-heading font-bold text-navy-800">{item.name}</h3>
                        {item.tierName && (
                          <span className="inline-block text-xs font-semibold text-navy-500 bg-navy-50 px-2 py-1 rounded-full mt-1">
                            {item.tierName}
                          </span>
                        )}
                      </div>
                      <button
                        onClick={() => removeItem(item.cartItemId)}
                        className="p-2 text-neutral-gray hover:text-red-500 transition-colors"
                        aria-label="Remove item"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>

                    {item.billingType === 'recurring' && (
                      <div className="flex items-center gap-1.5 text-sm text-navy-500 mt-2">
                        <RefreshCw className="w-4 h-4" /> Monthly subscription
                      </div>
                    )}

                    {item.bookingRequired && (
                      <div className="mt-2 space-y-1">
                        <div className="flex items-center gap-1.5 text-sm text-neutral-gray">
                          <Calendar className="w-4 h-4" />
                          {item.bookingDate && item.bookingTimeSlot
                            ? `${new Date(item.bookingDate).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })} at ${item.bookingTimeSlot}`
                            : <span className="text-orange-600">Booking details needed at checkout</span>}
                        </div>
                        {item.consultationMode && (
                          <div className="flex items-center gap-1.5 text-sm text-neutral-gray">
                            {item.consultationMode === 'online' ? <Video className="w-4 h-4" /> : <Building className="w-4 h-4" />}
                            {item.consultationMode === 'online' ? 'Online (Zoom/Meet)' : 'In-Studio'}
                          </div>
                        )}
                      </div>
                    )}

                    <div className="flex items-center justify-between mt-4">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => updateQuantity(item.cartItemId, item.quantity - 1)}
                          className="w-8 h-8 rounded-lg border border-gray-200 flex items-center justify-center hover:bg-gray-50 transition-colors"
                          disabled={item.quantity <= 1}
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="w-8 text-center font-semibold text-navy-800">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.cartItemId, item.quantity + 1)}
                          className="w-8 h-8 rounded-lg border border-gray-200 flex items-center justify-center hover:bg-gray-50 transition-colors"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="text-right">
                        <div className="font-heading font-bold text-lg text-navy-800">
                          {formatPrice(item.unitPrice * item.quantity)}
                        </div>
                        {item.billingType === 'recurring' && (
                          <div className="text-xs text-neutral-gray">{formatPrice(item.unitPrice)}/mo each</div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}

            <Link to="/services" className="inline-flex items-center gap-2 text-navy-500 hover:text-navy-800 transition-colors text-sm font-medium">
              <ArrowRight className="w-4 h-4 rotate-180" /> Continue Shopping
            </Link>
          </div>

          {/* Summary */}
          <div className="lg:col-span-1">
            <div className="card p-6 sticky top-24">
              <h2 className="font-heading font-bold text-xl text-navy-800 mb-4">Order Summary</h2>

              {oneTimeSubtotal > 0 && (
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-neutral-gray">One-time items</span>
                  <span className="font-semibold text-navy-800">{formatPrice(oneTimeSubtotal)}</span>
                </div>
              )}
              {recurringSubtotal > 0 && (
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-neutral-gray">Monthly subscriptions</span>
                  <span className="font-semibold text-navy-800">{formatPrice(recurringSubtotal)}/mo</span>
                </div>
              )}

              <div className="border-t border-gray-100 pt-4 mt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-gray">Subtotal</span>
                  <span className="font-semibold text-navy-800">{formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-gray">Tax (11%)</span>
                  <span className="font-semibold text-navy-800">{formatPrice(subtotal * 0.11)}</span>
                </div>
                <div className="flex justify-between font-heading font-bold text-lg pt-2 border-t border-gray-100">
                  <span className="text-navy-800">Total</span>
                  <span className="text-navy-800">{formatPrice(subtotal * 1.11)}</span>
                </div>
                {recurringSubtotal > 0 && (
                  <p className="text-xs text-neutral-gray mt-2">
                    Includes {formatPrice(recurringSubtotal)}/mo in recurring charges
                  </p>
                )}
              </div>

              <Link to="/checkout" className="btn-primary w-full mt-6 group">
                Proceed to Checkout
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>

              <div className="mt-4 text-center text-xs text-neutral-gray">
                Secure checkout. Your data is protected.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
