import { Link } from 'react-router-dom';
import { Home, ArrowLeft } from 'lucide-react';

export default function NotFoundPage() {
  return (
    <div className="pt-32 pb-16 min-h-[60vh] flex items-center">
      <div className="container-max px-4 text-center">
        <h1 className="font-heading font-extrabold text-6xl lg:text-8xl text-navy-800 mb-4">404</h1>
        <h2 className="font-heading font-bold text-2xl text-navy-800 mb-3">Page Not Found</h2>
        <p className="text-neutral-gray mb-8 max-w-md mx-auto">
          The page you are looking for does not exist or has been moved.
        </p>
        <div className="flex gap-4 justify-center">
          <Link to="/" className="btn-primary group">
            <Home className="w-4 h-4" /> Go Home
          </Link>
          <Link to="/services" className="btn-secondary">
            <ArrowLeft className="w-4 h-4" /> Browse Services
          </Link>
        </div>
      </div>
    </div>
  );
}
