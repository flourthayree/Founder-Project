import { useEffect, useState } from 'react';
import {
  Package, ShoppingBag, Users, FileText, Calendar, BarChart3,
  Tag, MessageSquare, LogOut, Plus, Edit, Trash2, X,
  RefreshCw, DollarSign,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { formatPrice, formatDate } from '../lib/utils';
import { Logo } from '../components/Logo';
import type { Product, Order, TeamMember, BlogPost, Program, ContactSubmission, PromoCode } from '../types';

type AdminTab = 'overview' | 'products' | 'orders' | 'team' | 'blog' | 'programs' | 'contact' | 'promo';

export default function AdminPage() {
  const { user, signOut, loading: authLoading } = useAuth();
  const [tab, setTab] = useState<AdminTab>('overview');
  const [loading, setLoading] = useState(true);

  // Data states
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>([]);
  const [programs, setPrograms] = useState<Program[]>([]);
  const [contacts, setContacts] = useState<ContactSubmission[]>([]);
  const [promoCodes, setPromoCodes] = useState<PromoCode[]>([]);

  // Stats
  const [stats, setStats] = useState({ revenue: 0, orders: 0, activeSubs: 0, bookings: 0 });

  useEffect(() => {
    if (!authLoading && !user) {
      window.location.href = '/auth';
      return;
    }
    if (!user) return;
    loadAllData();
  }, [user, authLoading]);

  const loadAllData = async () => {
    const [productsRes, ordersRes, teamRes, blogRes, programsRes, contactsRes, promoRes, subsRes, bookingsRes] = await Promise.all([
      supabase.from('products').select('*').order('sort_order'),
      supabase.from('orders').select('*').order('created_at', { ascending: false }),
      supabase.from('team_members').select('*').order('sort_order'),
      supabase.from('blog_posts').select('*').order('created_at', { ascending: false }),
      supabase.from('programs').select('*').order('event_date'),
      supabase.from('contact_submissions').select('*').order('created_at', { ascending: false }),
      supabase.from('promo_codes').select('*').order('created_at', { ascending: false }),
      supabase.from('subscriptions').select('*').eq('status', 'active'),
      supabase.from('bookings').select('*').eq('status', 'confirmed'),
    ]);

    setProducts(productsRes.data || []);
    setOrders(ordersRes.data || []);
    setTeam(teamRes.data || []);
    setBlogPosts(blogRes.data || []);
    setPrograms(programsRes.data || []);
    setContacts(contactsRes.data || []);
    setPromoCodes(promoRes.data || []);

    const allOrders = ordersRes.data || [];
    setStats({
      revenue: allOrders.reduce((sum, o) => sum + o.total, 0),
      orders: allOrders.length,
      activeSubs: (subsRes.data || []).length,
      bookings: (bookingsRes.data || []).length,
    });
    setLoading(false);
  };

  if (authLoading || loading) {
    return <div className="pt-32 pb-16 text-center"><div className="container-max px-4"><p className="text-neutral-gray">Loading admin panel...</p></div></div>;
  }

  const tabs: { id: AdminTab; label: string; icon: typeof Package }[] = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'products', label: 'Products', icon: Package },
    { id: 'orders', label: 'Orders', icon: ShoppingBag },
    { id: 'team', label: 'Team', icon: Users },
    { id: 'blog', label: 'Blog', icon: FileText },
    { id: 'programs', label: 'Programs', icon: Calendar },
    { id: 'contact', label: 'Messages', icon: MessageSquare },
    { id: 'promo', label: 'Promo Codes', icon: Tag },
  ];

  return (
    <div className="pt-24 pb-16 bg-neutral-light min-h-screen">
      <div className="container-max px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Logo className="w-10 h-10" variant="dark" />
            <div>
              <h1 className="font-heading font-extrabold text-2xl text-navy-800">Admin Panel</h1>
              <p className="text-sm text-neutral-gray">Manage your store content and orders</p>
            </div>
          </div>
          <button onClick={() => signOut()} className="btn-secondary !py-2">
            <LogOut className="w-4 h-4" /> Sign Out
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8 overflow-x-auto scrollbar-hide">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold whitespace-nowrap transition-all ${
                tab === t.id ? 'bg-navy-800 text-white' : 'bg-white text-navy-800 hover:bg-navy-50'
              }`}
            >
              <t.icon className="w-4 h-4" />
              {t.label}
            </button>
          ))}
        </div>

        {/* Overview */}
        {tab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard icon={DollarSign} label="Total Revenue" value={formatPrice(stats.revenue)} color="navy" />
              <StatCard icon={ShoppingBag} label="Total Orders" value={stats.orders.toString()} color="blue" />
              <StatCard icon={RefreshCw} label="Active Subscriptions" value={stats.activeSubs.toString()} color="green" />
              <StatCard icon={Calendar} label="Confirmed Bookings" value={stats.bookings.toString()} color="orange" />
            </div>

            <div className="card p-6">
              <h2 className="font-heading font-bold text-xl text-navy-800 mb-4">Popular Services</h2>
              <div className="space-y-3">
                {products.map((product) => (
                  <div key={product.id} className="flex items-center justify-between p-3 border border-gray-100 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg overflow-hidden">
                        <img src={product.image_url || ''} alt={product.name} className="w-full h-full object-cover" />
                      </div>
                      <span className="font-semibold text-navy-800">{product.name}</span>
                    </div>
                    <span className="text-sm text-neutral-gray">{formatPrice(product.starting_price)}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="card p-6">
              <h2 className="font-heading font-bold text-xl text-navy-800 mb-4">Recent Orders</h2>
              {orders.length === 0 ? (
                <p className="text-neutral-gray text-center py-4">No orders yet.</p>
              ) : (
                <div className="space-y-2">
                  {orders.slice(0, 5).map((order) => (
                    <div key={order.id} className="flex items-center justify-between p-3 border border-gray-100 rounded-xl">
                      <div>
                        <div className="font-semibold text-navy-800 text-sm">{order.order_number}</div>
                        <div className="text-xs text-neutral-gray">{order.customer_name} | {formatDate(order.created_at)}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold px-2 py-1 rounded-full bg-navy-100 text-navy-800">{order.status}</span>
                        <span className="font-semibold text-navy-800 text-sm">{formatPrice(order.total)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Products */}
        {tab === 'products' && <ProductsManager products={products} onUpdate={loadAllData} />}

        {/* Orders */}
        {tab === 'orders' && <OrdersManager orders={orders} onUpdate={loadAllData} />}

        {/* Team */}
        {tab === 'team' && <TeamManager team={team} onUpdate={loadAllData} />}

        {/* Blog */}
        {tab === 'blog' && <BlogManager posts={blogPosts} onUpdate={loadAllData} />}

        {/* Programs */}
        {tab === 'programs' && <ProgramsManager programs={programs} onUpdate={loadAllData} />}

        {/* Contact */}
        {tab === 'contact' && <ContactManager contacts={contacts} onUpdate={loadAllData} />}

        {/* Promo Codes */}
        {tab === 'promo' && <PromoManager promos={promoCodes} onUpdate={loadAllData} />}
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }: { icon: typeof Package; label: string; value: string; color: string }) {
  const colors: Record<string, string> = {
    navy: 'bg-navy-100 text-navy-800',
    blue: 'bg-blue-100 text-blue-600',
    green: 'bg-green-100 text-green-600',
    orange: 'bg-orange-100 text-orange-600',
  };
  return (
    <div className="card p-6">
      <div className={`rounded-xl p-3 w-fit mb-4 ${colors[color]}`}>
        <Icon className="w-6 h-6" />
      </div>
      <div className="text-2xl font-heading font-extrabold text-navy-800">{value}</div>
      <div className="text-sm text-neutral-gray mt-1">{label}</div>
    </div>
  );
}

// Products Manager
function ProductsManager({ products, onUpdate }: { products: Product[]; onUpdate: () => void }) {
  const [editing, setEditing] = useState<Product | null>(null);
  const [creating, setCreating] = useState(false);

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this product?')) return;
    await supabase.from('products').delete().eq('id', id);
    onUpdate();
  };

  const handleToggleActive = async (product: Product) => {
    await supabase.from('products').update({ is_active: !product.is_active }).eq('id', product.id);
    onUpdate();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-heading font-bold text-xl text-navy-800">Manage Products</h2>
        <button onClick={() => setCreating(true)} className="btn-primary !py-2">
          <Plus className="w-4 h-4" /> Add Product
        </button>
      </div>
      <div className="space-y-3">
        {products.map((product) => (
          <div key={product.id} className="card p-4 flex items-center gap-4">
            <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
              <img src={product.image_url || ''} alt={product.name} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-navy-800 truncate">{product.name}</h3>
              <p className="text-sm text-neutral-gray">{product.category} | {formatPrice(product.starting_price)} | {product.billing_type}</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleToggleActive(product)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${product.is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-neutral-gray'}`}
              >
                {product.is_active ? 'Active' : 'Inactive'}
              </button>
              <button onClick={() => setEditing(product)} className="p-2 text-navy-500 hover:bg-navy-50 rounded-lg transition-colors">
                <Edit className="w-4 h-4" />
              </button>
              <button onClick={() => handleDelete(product.id)} className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
      {(editing || creating) && (
        <ProductEditModal
          product={editing}
          onClose={() => { setEditing(null); setCreating(false); }}
          onSave={() => { setEditing(null); setCreating(false); onUpdate(); }}
        />
      )}
    </div>
  );
}

function ProductEditModal({ product, onClose, onSave }: { product: Product | null; onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState({
    name: product?.name || '',
    slug: product?.slug || '',
    tagline: product?.tagline || '',
    description: product?.description || '',
    image_url: product?.image_url || '',
    category: product?.category || 'Consulting',
    pricing_type: (product?.pricing_type || 'flat') as 'flat' | 'tiered' | 'per_session' | 'per_project',
    billing_type: (product?.billing_type || 'one_time') as 'one_time' | 'recurring',
    booking_required: product?.booking_required || false,
    starting_price: product?.starting_price || 0,
    is_active: product?.is_active ?? true,
    sort_order: product?.sort_order || 0,
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    if (product) {
      await supabase.from('products').update(form).eq('id', product.id);
    } else {
      await supabase.from('products').insert(form);
    }
    setSaving(false);
    onSave();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-bold text-xl text-navy-800">{product ? 'Edit Product' : 'Add Product'}</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg"><X className="w-5 h-5" /></button>
        </div>
        <div className="space-y-4">
          <Field label="Name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} />
          <Field label="Slug" value={form.slug} onChange={(v) => setForm({ ...form, slug: v })} />
          <Field label="Tagline" value={form.tagline} onChange={(v) => setForm({ ...form, tagline: v })} />
          <Field label="Image URL" value={form.image_url} onChange={(v) => setForm({ ...form, image_url: v })} />
          <Field label="Description" value={form.description} onChange={(v) => setForm({ ...form, description: v })} textarea />
          <div className="grid grid-cols-2 gap-4">
            <SelectField label="Category" value={form.category} options={['Consulting', 'Branding', 'Marketing', 'Creative']} onChange={(v) => setForm({ ...form, category: v })} />
            <SelectField label="Pricing Type" value={form.pricing_type} options={['flat', 'tiered', 'per_session', 'per_project']} onChange={(v) => setForm({ ...form, pricing_type: v as 'flat' | 'tiered' | 'per_session' | 'per_project' })} />
            <SelectField label="Billing Type" value={form.billing_type} options={['one_time', 'recurring']} onChange={(v) => setForm({ ...form, billing_type: v as 'one_time' | 'recurring' })} />
            <Field label="Starting Price" value={form.starting_price.toString()} onChange={(v) => setForm({ ...form, starting_price: Number(v) })} type="number" />
          </div>
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={form.booking_required} onChange={(e) => setForm({ ...form, booking_required: e.target.checked })} className="w-4 h-4" />
            <span className="text-sm text-navy-800">Booking Required</span>
          </label>
        </div>
        <button onClick={handleSave} disabled={saving} className="btn-primary w-full mt-6">
          {saving ? 'Saving...' : 'Save Product'}
        </button>
      </div>
    </div>
  );
}

// Orders Manager
function OrdersManager({ orders, onUpdate }: { orders: Order[]; onUpdate: () => void }) {
  const updateStatus = async (id: string, status: string) => {
    await supabase.from('orders').update({ status }).eq('id', id);
    onUpdate();
  };

  return (
    <div>
      <h2 className="font-heading font-bold text-xl text-navy-800 mb-4">Manage Orders</h2>
      {orders.length === 0 ? (
        <div className="card p-12 text-center">
          <ShoppingBag className="w-12 h-12 text-neutral-gray mx-auto mb-4" />
          <p className="text-neutral-gray">No orders yet.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {orders.map((order) => (
            <div key={order.id} className="card p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="font-semibold text-navy-800">{order.order_number}</div>
                  <div className="text-sm text-neutral-gray">{order.customer_name} | {order.customer_email}</div>
                  <div className="text-xs text-neutral-gray">{formatDate(order.created_at)}</div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-semibold text-navy-800">{formatPrice(order.total)}</span>
                  <select
                    value={order.status}
                    onChange={(e) => updateStatus(order.id, e.target.value)}
                    className="px-3 py-1.5 rounded-lg border border-gray-200 text-sm font-semibold text-navy-800"
                  >
                    <option value="pending">Pending</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// Team Manager
function TeamManager({ team, onUpdate }: { team: TeamMember[]; onUpdate: () => void }) {
  const [editing, setEditing] = useState<TeamMember | null>(null);
  const [creating, setCreating] = useState(false);

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this team member?')) return;
    await supabase.from('team_members').delete().eq('id', id);
    onUpdate();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-heading font-bold text-xl text-navy-800">Manage Team</h2>
        <button onClick={() => setCreating(true)} className="btn-primary !py-2">
          <Plus className="w-4 h-4" /> Add Member
        </button>
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        {team.map((member) => (
          <div key={member.id} className="card p-4 flex gap-4">
            <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0">
              <img src={member.photo_url || ''} alt={member.full_name} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-navy-800">{member.full_name}</h3>
              <p className="text-sm text-neutral-gray line-clamp-3">{member.bio}</p>
              <div className="flex gap-2 mt-2">
                <button onClick={() => setEditing(member)} className="p-1.5 text-navy-500 hover:bg-navy-50 rounded-lg">
                  <Edit className="w-4 h-4" />
                </button>
                <button onClick={() => handleDelete(member.id)} className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      {(editing || creating) && (
        <TeamEditModal
          member={editing}
          onClose={() => { setEditing(null); setCreating(false); }}
          onSave={() => { setEditing(null); setCreating(false); onUpdate(); }}
        />
      )}
    </div>
  );
}

function TeamEditModal({ member, onClose, onSave }: { member: TeamMember | null; onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState({
    full_name: member?.full_name || '',
    bio: member?.bio || '',
    photo_url: member?.photo_url || '',
    sort_order: member?.sort_order || 1,
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    if (member) {
      await supabase.from('team_members').update(form).eq('id', member.id);
    } else {
      await supabase.from('team_members').insert(form);
    }
    setSaving(false);
    onSave();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-bold text-xl text-navy-800">{member ? 'Edit Member' : 'Add Member'}</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg"><X className="w-5 h-5" /></button>
        </div>
        <div className="space-y-4">
          <Field label="Full Name" value={form.full_name} onChange={(v) => setForm({ ...form, full_name: v })} />
          <Field label="Photo URL" value={form.photo_url} onChange={(v) => setForm({ ...form, photo_url: v })} />
          <Field label="Bio" value={form.bio} onChange={(v) => setForm({ ...form, bio: v })} textarea />
          <Field label="Sort Order" value={form.sort_order.toString()} onChange={(v) => setForm({ ...form, sort_order: Number(v) })} type="number" />
        </div>
        <button onClick={handleSave} disabled={saving} className="btn-primary w-full mt-6">
          {saving ? 'Saving...' : 'Save Member'}
        </button>
      </div>
    </div>
  );
}

// Blog Manager
function BlogManager({ posts, onUpdate }: { posts: BlogPost[]; onUpdate: () => void }) {
  const [editing, setEditing] = useState<BlogPost | null>(null);
  const [creating, setCreating] = useState(false);

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this blog post?')) return;
    await supabase.from('blog_posts').delete().eq('id', id);
    onUpdate();
  };

  const togglePublish = async (post: BlogPost) => {
    await supabase.from('blog_posts').update({ published: !post.published, published_at: !post.published ? new Date().toISOString() : post.published_at }).eq('id', post.id);
    onUpdate();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-heading font-bold text-xl text-navy-800">Manage Blog</h2>
        <button onClick={() => setCreating(true)} className="btn-primary !py-2">
          <Plus className="w-4 h-4" /> Add Post
        </button>
      </div>
      <div className="space-y-3">
        {posts.map((post) => (
          <div key={post.id} className="card p-4 flex items-center gap-4">
            <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
              <img src={post.image_url || ''} alt={post.title} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-navy-800 truncate">{post.title}</h3>
              <p className="text-sm text-neutral-gray">{post.category} | {post.author}</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => togglePublish(post)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${post.published ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-neutral-gray'}`}
              >
                {post.published ? 'Published' : 'Draft'}
              </button>
              <button onClick={() => setEditing(post)} className="p-2 text-navy-500 hover:bg-navy-50 rounded-lg">
                <Edit className="w-4 h-4" />
              </button>
              <button onClick={() => handleDelete(post.id)} className="p-2 text-red-500 hover:bg-red-50 rounded-lg">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
      {(editing || creating) && (
        <BlogEditModal
          post={editing}
          onClose={() => { setEditing(null); setCreating(false); }}
          onSave={() => { setEditing(null); setCreating(false); onUpdate(); }}
        />
      )}
    </div>
  );
}

function BlogEditModal({ post, onClose, onSave }: { post: BlogPost | null; onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState({
    title: post?.title || '',
    slug: post?.slug || '',
    excerpt: post?.excerpt || '',
    content: post?.content || '',
    image_url: post?.image_url || '',
    category: post?.category || 'Entrepreneurship',
    author: post?.author || 'The Founder Project',
    published: post?.published ?? false,
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    const data = { ...form, published_at: form.published ? new Date().toISOString() : null };
    if (post) {
      await supabase.from('blog_posts').update(data).eq('id', post.id);
    } else {
      await supabase.from('blog_posts').insert(data);
    }
    setSaving(false);
    onSave();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-bold text-xl text-navy-800">{post ? 'Edit Post' : 'Add Post'}</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg"><X className="w-5 h-5" /></button>
        </div>
        <div className="space-y-4">
          <Field label="Title" value={form.title} onChange={(v) => setForm({ ...form, title: v })} />
          <Field label="Slug" value={form.slug} onChange={(v) => setForm({ ...form, slug: v })} />
          <Field label="Excerpt" value={form.excerpt || ''} onChange={(v) => setForm({ ...form, excerpt: v })} textarea />
          <Field label="Content" value={form.content || ''} onChange={(v) => setForm({ ...form, content: v })} textarea />
          <Field label="Image URL" value={form.image_url || ''} onChange={(v) => setForm({ ...form, image_url: v })} />
          <div className="grid grid-cols-2 gap-4">
            <Field label="Author" value={form.author || ''} onChange={(v) => setForm({ ...form, author: v })} />
            <SelectField label="Category" value={form.category || ''} options={['Entrepreneurship', 'Branding', 'Marketing', 'Creative']} onChange={(v) => setForm({ ...form, category: v })} />
          </div>
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={form.published} onChange={(e) => setForm({ ...form, published: e.target.checked })} className="w-4 h-4" />
            <span className="text-sm text-navy-800">Published</span>
          </label>
        </div>
        <button onClick={handleSave} disabled={saving} className="btn-primary w-full mt-6">
          {saving ? 'Saving...' : 'Save Post'}
        </button>
      </div>
    </div>
  );
}

// Programs Manager
function ProgramsManager({ programs, onUpdate }: { programs: Program[]; onUpdate: () => void }) {
  const [editing, setEditing] = useState<Program | null>(null);
  const [creating, setCreating] = useState(false);

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this program?')) return;
    await supabase.from('programs').delete().eq('id', id);
    onUpdate();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-heading font-bold text-xl text-navy-800">Manage Programs</h2>
        <button onClick={() => setCreating(true)} className="btn-primary !py-2">
          <Plus className="w-4 h-4" /> Add Program
        </button>
      </div>
      <div className="space-y-3">
        {programs.map((program) => (
          <div key={program.id} className="card p-4 flex items-center gap-4">
            <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
              <img src={program.image_url || ''} alt={program.title} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-navy-800 truncate">{program.title}</h3>
              <p className="text-sm text-neutral-gray">{program.program_type} | {program.event_date ? formatDate(program.event_date) : 'TBA'} | {program.location}</p>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setEditing(program)} className="p-2 text-navy-500 hover:bg-navy-50 rounded-lg">
                <Edit className="w-4 h-4" />
              </button>
              <button onClick={() => handleDelete(program.id)} className="p-2 text-red-500 hover:bg-red-50 rounded-lg">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
      {(editing || creating) && (
        <ProgramEditModal
          program={editing}
          onClose={() => { setEditing(null); setCreating(false); }}
          onSave={() => { setEditing(null); setCreating(false); onUpdate(); }}
        />
      )}
    </div>
  );
}

function ProgramEditModal({ program, onClose, onSave }: { program: Program | null; onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState({
    title: program?.title || '',
    slug: program?.slug || '',
    description: program?.description || '',
    image_url: program?.image_url || '',
    program_type: program?.program_type || 'workshop',
    event_date: program?.event_date || '',
    location: program?.location || '',
    capacity: program?.capacity || 50,
    is_active: program?.is_active ?? true,
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    const data = { ...form, event_date: form.event_date || null };
    if (program) {
      await supabase.from('programs').update(data).eq('id', program.id);
    } else {
      await supabase.from('programs').insert(data);
    }
    setSaving(false);
    onSave();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-bold text-xl text-navy-800">{program ? 'Edit Program' : 'Add Program'}</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg"><X className="w-5 h-5" /></button>
        </div>
        <div className="space-y-4">
          <Field label="Title" value={form.title} onChange={(v) => setForm({ ...form, title: v })} />
          <Field label="Slug" value={form.slug} onChange={(v) => setForm({ ...form, slug: v })} />
          <Field label="Description" value={form.description || ''} onChange={(v) => setForm({ ...form, description: v })} textarea />
          <Field label="Image URL" value={form.image_url || ''} onChange={(v) => setForm({ ...form, image_url: v })} />
          <div className="grid grid-cols-2 gap-4">
            <SelectField label="Type" value={form.program_type} options={['workshop', 'webinar', 'collaboration']} onChange={(v) => setForm({ ...form, program_type: v })} />
            <Field label="Date" value={form.event_date} onChange={(v) => setForm({ ...form, event_date: v })} type="date" />
            <Field label="Location" value={form.location || ''} onChange={(v) => setForm({ ...form, location: v })} />
            <Field label="Capacity" value={form.capacity?.toString() || '50'} onChange={(v) => setForm({ ...form, capacity: Number(v) })} type="number" />
          </div>
        </div>
        <button onClick={handleSave} disabled={saving} className="btn-primary w-full mt-6">
          {saving ? 'Saving...' : 'Save Program'}
        </button>
      </div>
    </div>
  );
}

// Contact Manager
function ContactManager({ contacts, onUpdate }: { contacts: ContactSubmission[]; onUpdate: () => void }) {
  const updateStatus = async (id: string, status: string) => {
    await supabase.from('contact_submissions').update({ status }).eq('id', id);
    onUpdate();
  };

  return (
    <div>
      <h2 className="font-heading font-bold text-xl text-navy-800 mb-4">Messages</h2>
      {contacts.length === 0 ? (
        <div className="card p-12 text-center">
          <MessageSquare className="w-12 h-12 text-neutral-gray mx-auto mb-4" />
          <p className="text-neutral-gray">No messages yet.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {contacts.map((contact) => (
            <div key={contact.id} className="card p-4">
              <div className="flex items-start justify-between gap-3 mb-2">
                <div>
                  <div className="font-semibold text-navy-800">{contact.name}</div>
                  <div className="text-sm text-neutral-gray">{contact.email} {contact.phone && `| ${contact.phone}`}</div>
                  <div className="text-xs text-navy-500 font-semibold mt-1">{contact.submission_type}</div>
                </div>
                <select
                  value={contact.status}
                  onChange={(e) => updateStatus(contact.id, e.target.value)}
                  className="px-3 py-1.5 rounded-lg border border-gray-200 text-sm font-semibold text-navy-800"
                >
                  <option value="new">New</option>
                  <option value="responded">Responded</option>
                  <option value="closed">Closed</option>
                </select>
              </div>
              <p className="text-sm text-navy-800 bg-neutral-light p-3 rounded-lg mt-2">{contact.message}</p>
              <div className="text-xs text-neutral-gray mt-2">{formatDate(contact.created_at)}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// Promo Manager
function PromoManager({ promos, onUpdate }: { promos: PromoCode[]; onUpdate: () => void }) {
  const [creating, setCreating] = useState(false);

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this promo code?')) return;
    await supabase.from('promo_codes').delete().eq('id', id);
    onUpdate();
  };

  const toggleActive = async (promo: PromoCode) => {
    await supabase.from('promo_codes').update({ is_active: !promo.is_active }).eq('id', promo.id);
    onUpdate();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-heading font-bold text-xl text-navy-800">Promo Codes</h2>
        <button onClick={() => setCreating(true)} className="btn-primary !py-2">
          <Plus className="w-4 h-4" /> Add Code
        </button>
      </div>
      <div className="space-y-3">
        {promos.map((promo) => (
          <div key={promo.id} className="card p-4 flex items-center justify-between">
            <div>
              <div className="font-heading font-bold text-navy-800">{promo.code}</div>
              <div className="text-sm text-neutral-gray">
                {promo.discount_type === 'percentage' ? `${promo.discount_value}% off` : `${formatPrice(promo.discount_value)} off`}
                {promo.max_uses && ` | ${promo.used_count}/${promo.max_uses} used`}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => toggleActive(promo)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${promo.is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-neutral-gray'}`}
              >
                {promo.is_active ? 'Active' : 'Inactive'}
              </button>
              <button onClick={() => handleDelete(promo.id)} className="p-2 text-red-500 hover:bg-red-50 rounded-lg">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
      {creating && (
        <PromoEditModal
          onClose={() => setCreating(false)}
          onSave={() => { setCreating(false); onUpdate(); }}
        />
      )}
    </div>
  );
}

function PromoEditModal({ onClose, onSave }: { onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState({
    code: '',
    discount_type: 'percentage',
    discount_value: 10,
    max_uses: 100,
    is_active: true,
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    await supabase.from('promo_codes').insert({ ...form, code: form.code.toUpperCase() });
    setSaving(false);
    onSave();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl p-6 max-w-md w-full" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-bold text-xl text-navy-800">Add Promo Code</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg"><X className="w-5 h-5" /></button>
        </div>
        <div className="space-y-4">
          <Field label="Code" value={form.code} onChange={(v) => setForm({ ...form, code: v })} />
          <div className="grid grid-cols-2 gap-4">
            <SelectField label="Type" value={form.discount_type} options={['percentage', 'fixed']} onChange={(v) => setForm({ ...form, discount_type: v })} />
            <Field label="Value" value={form.discount_value.toString()} onChange={(v) => setForm({ ...form, discount_value: Number(v) })} type="number" />
          </div>
          <Field label="Max Uses" value={form.max_uses?.toString() || ''} onChange={(v) => setForm({ ...form, max_uses: Number(v) })} type="number" />
        </div>
        <button onClick={handleSave} disabled={saving} className="btn-primary w-full mt-6">
          {saving ? 'Saving...' : 'Save Code'}
        </button>
      </div>
    </div>
  );
}

// Helper components
function Field({ label, value, onChange, textarea, type = 'text' }: { label: string; value: string; onChange: (v: string) => void; textarea?: boolean; type?: string }) {
  return (
    <div>
      <label className="text-sm font-medium text-navy-800 mb-1 block">{label}</label>
      {textarea ? (
        <textarea value={value} onChange={(e) => onChange(e.target.value)} className="input-field min-h-[80px] resize-y" />
      ) : (
        <input type={type} value={value} onChange={(e) => onChange(e.target.value)} className="input-field" />
      )}
    </div>
  );
}

function SelectField({ label, value, options, onChange }: { label: string; value: string; options: string[]; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="text-sm font-medium text-navy-800 mb-1 block">{label}</label>
      <select value={value} onChange={(e) => onChange(e.target.value)} className="input-field">
        {options.map((opt) => (
          <option key={opt} value={opt}>{opt}</option>
        ))}
      </select>
    </div>
  );
}
