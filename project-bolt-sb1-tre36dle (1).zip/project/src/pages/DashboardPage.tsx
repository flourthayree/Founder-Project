import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Package, RefreshCw, Calendar, Clock, Video, MapPin, TrendingUp,
  LogOut, ShoppingBag, CreditCard,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { formatPrice, formatDate } from '../lib/utils';
import type { Order, Subscription, Booking } from '../types';

type Tab = 'overview' | 'orders' | 'subscriptions' | 'bookings';

export default function DashboardPage() {
  const { user, signOut, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>('overview');
  const [orders, setOrders] = useState<Order[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
      return;
    }
    if (!user) return;

    (async () => {
      const [ordersRes, subsRes, bookingsRes] = await Promise.all([
        supabase.from('orders').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
        supabase.from('subscriptions').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
        supabase.from('bookings').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
      ]);
      setOrders(ordersRes.data || []);
      setSubscriptions(subsRes.data || []);
      setBookings(bookingsRes.data || []);
      setLoading(false);
    })();
  }, [user, authLoading, navigate]);

  const handleCancelSubscription = async (id: string) => {
    if (!confirm('Are you sure you want to cancel this subscription?')) return;
    await supabase.from('subscriptions').update({ status: 'cancelled', cancelled_at: new Date().toISOString() }).eq('id', id);
    setSubscriptions((prev) => prev.map((s) => (s.id === id ? { ...s, status: 'cancelled' } : s)));
  };

  const handleCancelBooking = async (id: string) => {
    if (!confirm('Are you sure you want to cancel this booking?')) return;
    await supabase.from('bookings').update({ status: 'cancelled' }).eq('id', id);
    setBookings((prev) => prev.map((b) => (b.id === id ? { ...b, status: 'cancelled' } : b)));
  };

  if (authLoading || (!user && !authLoading)) {
    return <div className="pt-32 pb-16 text-center"><div className="container-max px-4"><p className="text-neutral-gray">Loading...</p></div></div>;
  }

  const totalSpent = orders.reduce((sum, o) => sum + o.total, 0);
  const activeSubs = subscriptions.filter((s) => s.status === 'active');
  const activeBookings = bookings.filter((b) => b.status === 'confirmed' || b.status === 'pending');

  const tabs: { id: Tab; label: string; icon: typeof Package; count: number }[] = [
    { id: 'overview', label: 'Overview', icon: TrendingUp, count: 0 },
    { id: 'orders', label: 'Orders', icon: ShoppingBag, count: orders.length },
    { id: 'subscriptions', label: 'Subscriptions', icon: RefreshCw, count: activeSubs.length },
    { id: 'bookings', label: 'Bookings', icon: Calendar, count: activeBookings.length },
  ];

  const statusColors: Record<string, string> = {
    pending: 'bg-orange-100 text-orange-800',
    confirmed: 'bg-blue-100 text-blue-800',
    completed: 'bg-green-100 text-green-800',
    cancelled: 'bg-red-100 text-red-800',
    active: 'bg-green-100 text-green-800',
    past_due: 'bg-orange-100 text-orange-800',
    trialing: 'bg-blue-100 text-blue-800',
  };

  return (
    <div className="pt-32 pb-16 bg-neutral-light min-h-screen">
      <div className="container-max px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-heading font-extrabold text-3xl text-navy-800">My Dashboard</h1>
            <p className="text-neutral-gray">Welcome back, {user?.email}</p>
          </div>
          <button onClick={() => signOut()} className="btn-secondary !py-2">
            <LogOut className="w-4 h-4" /> Sign Out
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8 overflow-x-auto scrollbar-hide">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold whitespace-nowrap transition-all ${
                tab === t.id ? 'bg-navy-800 text-white' : 'bg-white text-navy-800 hover:bg-navy-50'
              }`}
            >
              <t.icon className="w-4 h-4" />
              {t.label}
              {t.count > 0 && (
                <span className={`px-2 py-0.5 rounded-full text-xs ${tab === t.id ? 'bg-white/20' : 'bg-navy-100'}`}>
                  {t.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="card h-64 animate-pulse bg-gray-100" />
        ) : (
          <>
            {/* Overview */}
            {tab === 'overview' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="card p-6">
                    <div className="bg-navy-100 rounded-xl p-3 w-fit mb-4">
                      <CreditCard className="w-6 h-6 text-navy-800" />
                    </div>
                    <div className="text-2xl font-heading font-extrabold text-navy-800">{formatPrice(totalSpent)}</div>
                    <div className="text-sm text-neutral-gray mt-1">Total Spent</div>
                  </div>
                  <div className="card p-6">
                    <div className="bg-green-100 rounded-xl p-3 w-fit mb-4">
                      <RefreshCw className="w-6 h-6 text-green-600" />
                    </div>
                    <div className="text-2xl font-heading font-extrabold text-navy-800">{activeSubs.length}</div>
                    <div className="text-sm text-neutral-gray mt-1">Active Subscriptions</div>
                  </div>
                  <div className="card p-6">
                    <div className="bg-blue-100 rounded-xl p-3 w-fit mb-4">
                      <Calendar className="w-6 h-6 text-blue-600" />
                    </div>
                    <div className="text-2xl font-heading font-extrabold text-navy-800">{activeBookings.length}</div>
                    <div className="text-sm text-neutral-gray mt-1">Upcoming Bookings</div>
                  </div>
                </div>

                <div className="card p-6">
                  <h2 className="font-heading font-bold text-xl text-navy-800 mb-4">Recent Orders</h2>
                  {orders.length === 0 ? (
                    <p className="text-neutral-gray text-center py-8">No orders yet. <Link to="/services" className="text-navy-500 font-semibold">Browse services</Link></p>
                  ) : (
                    <div className="space-y-3">
                      {orders.slice(0, 3).map((order) => (
                        <div key={order.id} className="flex items-center justify-between p-4 border border-gray-100 rounded-xl">
                          <div>
                            <div className="font-semibold text-navy-800">{order.order_number}</div>
                            <div className="text-sm text-neutral-gray">{formatDate(order.created_at)}</div>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${statusColors[order.status] || 'bg-gray-100'}`}>
                              {order.status}
                            </span>
                            <span className="font-semibold text-navy-800">{formatPrice(order.total)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Orders */}
            {tab === 'orders' && (
              <div className="card p-6">
                <h2 className="font-heading font-bold text-xl text-navy-800 mb-4">Order History</h2>
                {orders.length === 0 ? (
                  <div className="text-center py-12">
                    <Package className="w-12 h-12 text-neutral-gray mx-auto mb-4" />
                    <p className="text-neutral-gray mb-4">No orders yet.</p>
                    <Link to="/services" className="btn-primary">Browse Services</Link>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {orders.map((order) => (
                      <div key={order.id} className="border border-gray-100 rounded-xl p-4">
                        <div className="flex items-center justify-between mb-2">
                          <div>
                            <div className="font-semibold text-navy-800">{order.order_number}</div>
                            <div className="text-sm text-neutral-gray">{formatDate(order.created_at)}</div>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${statusColors[order.status] || 'bg-gray-100'}`}>
                              {order.status}
                            </span>
                            <span className="font-semibold text-navy-800">{formatPrice(order.total)}</span>
                          </div>
                        </div>
                        <div className="text-sm text-neutral-gray">
                          Payment: {order.payment_method?.replace('_', ' ')}
                          {order.promo_code && ` | Promo: ${order.promo_code}`}
                        </div>
                        <Link to={`/order-confirmation/${order.order_number}`} className="text-sm text-navy-500 hover:text-navy-800 font-medium mt-2 inline-block">
                          View Details →
                        </Link>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Subscriptions */}
            {tab === 'subscriptions' && (
              <div className="card p-6">
                <h2 className="font-heading font-bold text-xl text-navy-800 mb-4">My Subscriptions</h2>
                {subscriptions.length === 0 ? (
                  <div className="text-center py-12">
                    <RefreshCw className="w-12 h-12 text-neutral-gray mx-auto mb-4" />
                    <p className="text-neutral-gray mb-4">No subscriptions yet.</p>
                    <Link to="/services" className="btn-primary">Browse Services</Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {subscriptions.map((sub) => (
                      <div key={sub.id} className="border border-gray-100 rounded-xl p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <div className="font-semibold text-navy-800">{sub.tier_name || 'Subscription'}</div>
                            <div className="text-sm text-neutral-gray">{formatPrice(sub.amount)}/month</div>
                          </div>
                          <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${statusColors[sub.status] || 'bg-gray-100'}`}>
                            {sub.status}
                          </span>
                        </div>
                        <div className="text-sm text-neutral-gray mb-3">
                          {sub.current_period_start && `Started: ${formatDate(sub.current_period_start)}`}
                          {sub.current_period_end && ` | Renews: ${formatDate(sub.current_period_end)}`}
                          {sub.cancelled_at && ` | Cancelled: ${formatDate(sub.cancelled_at)}`}
                        </div>
                        {sub.status === 'active' && (
                          <div className="flex gap-2">
                            <Link to="/services" className="text-sm text-navy-500 hover:text-navy-800 font-medium">Upgrade/Downgrade</Link>
                            <span className="text-neutral-gray">|</span>
                            <button onClick={() => handleCancelSubscription(sub.id)} className="text-sm text-red-500 hover:text-red-700 font-medium">
                              Cancel Subscription
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Bookings */}
            {tab === 'bookings' && (
              <div className="card p-6">
                <h2 className="font-heading font-bold text-xl text-navy-800 mb-4">My Bookings</h2>
                {bookings.length === 0 ? (
                  <div className="text-center py-12">
                    <Calendar className="w-12 h-12 text-neutral-gray mx-auto mb-4" />
                    <p className="text-neutral-gray mb-4">No bookings yet.</p>
                    <Link to="/services" className="btn-primary">Browse Services</Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {bookings.map((booking) => (
                      <div key={booking.id} className="border border-gray-100 rounded-xl p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <div className="bg-navy-100 rounded-lg p-2">
                              <Calendar className="w-5 h-5 text-navy-800" />
                            </div>
                            <div>
                              <div className="font-semibold text-navy-800">{formatDate(booking.booking_date)}</div>
                              <div className="text-sm text-neutral-gray flex items-center gap-1">
                                <Clock className="w-3.5 h-3.5" /> {booking.time_slot}
                              </div>
                            </div>
                          </div>
                          <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${statusColors[booking.status] || 'bg-gray-100'}`}>
                            {booking.status}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-navy-800 mb-3">
                          {booking.consultation_mode === 'online' ? (
                            <><Video className="w-4 h-4" /> Online Session</>
                          ) : (
                            <><MapPin className="w-4 h-4" /> {booking.location || 'In-Studio'}</>
                          )}
                        </div>
                        {booking.meeting_link && booking.status === 'confirmed' && (
                          <a href={booking.meeting_link} target="_blank" rel="noopener noreferrer" className="text-sm text-navy-500 hover:text-navy-800 font-medium flex items-center gap-1.5 mb-2">
                            <Video className="w-4 h-4" /> Join Meeting
                          </a>
                        )}
                        {(booking.status === 'confirmed' || booking.status === 'pending') && (
                          <button onClick={() => handleCancelBooking(booking.id)} className="text-sm text-red-500 hover:text-red-700 font-medium">
                            Cancel Booking
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
