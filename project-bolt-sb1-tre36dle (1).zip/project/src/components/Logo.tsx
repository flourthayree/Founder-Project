interface LogoProps {
  className?: string;
  variant?: 'dark' | 'light';
  showText?: boolean;
}

export function Logo({ className = 'w-10 h-10', variant = 'dark', showText = false }: LogoProps) {
  return (
    <div className="flex items-center gap-3">
      <div
        className={`${className} rounded-full flex-shrink-0 overflow-hidden ${
          variant === 'dark'
            ? 'ring-2 ring-white/20'
            : 'ring-1 ring-gray-200'
        }`}
        role="img"
        aria-label="The Founder Project Logo"
      >
        <img
          src="/logo.svg"
          alt="The Founder Project Logo"
          className={`w-full h-full object-contain rounded-full ${
            variant === 'dark' ? 'invert' : ''
          }`}
        />
      </div>
      {showText && (
        <div className="flex flex-col leading-none">
          <span className={`font-heading font-extrabold text-lg ${variant === 'dark' ? 'text-white' : 'text-navy-800'}`}>
            The Founder
          </span>
          <span className={`font-heading font-bold text-sm tracking-widest ${variant === 'dark' ? 'text-navy-200' : 'text-neutral-gray'}`}>
            PROJECT
          </span>
        </div>
      )}
    </div>
  );
}
