import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, Instagram, Linkedin, Twitter } from 'lucide-react';
import { Logo } from './Logo';

export function Footer() {
  return (
    <footer className="bg-navy-800 text-white">
      <div className="container-max px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div className="lg:col-span-1">
            <Logo className="w-12 h-12 mb-4" variant="dark" showText />
            <p className="text-navy-200 text-sm leading-relaxed mt-4">
              Building Future Founders Through Business & Marketing Ecosystem. A student-driven creative agency.
            </p>
            <div className="flex gap-3 mt-6">
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="p-2 bg-white/10 rounded-lg hover:bg-white/20 transition-colors" aria-label="Instagram">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="p-2 bg-white/10 rounded-lg hover:bg-white/20 transition-colors" aria-label="LinkedIn">
                <Linkedin className="w-4 h-4" />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="p-2 bg-white/10 rounded-lg hover:bg-white/20 transition-colors" aria-label="Twitter">
                <Twitter className="w-4 h-4" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-heading font-bold text-sm uppercase tracking-wider text-white mb-4">Services</h3>
            <ul className="space-y-3">
              <li><Link to="/services/business-consulting" className="text-navy-200 hover:text-white text-sm transition-colors">Business Consulting</Link></li>
              <li><Link to="/services/brand-identity" className="text-navy-200 hover:text-white text-sm transition-colors">Brand Identity</Link></li>
              <li><Link to="/services/social-media-management" className="text-navy-200 hover:text-white text-sm transition-colors">Social Media Management</Link></li>
              <li><Link to="/services/creative-content-production" className="text-navy-200 hover:text-white text-sm transition-colors">Creative Content</Link></li>
              <li><Link to="/services/portfolio-website-review" className="text-navy-200 hover:text-white text-sm transition-colors">Portfolio Review</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-heading font-bold text-sm uppercase tracking-wider text-white mb-4">Company</h3>
            <ul className="space-y-3">
              <li><Link to="/about" className="text-navy-200 hover:text-white text-sm transition-colors">About Us</Link></li>
              <li><Link to="/programs" className="text-navy-200 hover:text-white text-sm transition-colors">Programs</Link></li>
              <li><Link to="/blog" className="text-navy-200 hover:text-white text-sm transition-colors">Blog</Link></li>
              <li><Link to="/contact" className="text-navy-200 hover:text-white text-sm transition-colors">Contact</Link></li>
              <li><Link to="/contact" className="text-navy-200 hover:text-white text-sm transition-colors">Join the Community</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-heading font-bold text-sm uppercase tracking-wider text-white mb-4">Get in Touch</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3 text-navy-200 text-sm">
                <Mail className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <a href="mailto:hello@founderproject.id" className="hover:text-white transition-colors">hello@founderproject.id</a>
              </li>
              <li className="flex items-start gap-3 text-navy-200 text-sm">
                <Phone className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <span>+62 812 3456 7890</span>
              </li>
              <li className="flex items-start gap-3 text-navy-200 text-sm">
                <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <span>Jakarta, Indonesia</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 mt-12 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-navy-200 text-sm">
            &copy; {new Date().getFullYear()} The Founder Project. All rights reserved.
          </p>
          <div className="flex gap-6">
            <Link to="/about" className="text-navy-200 hover:text-white text-sm transition-colors">Privacy</Link>
            <Link to="/about" className="text-navy-200 hover:text-white text-sm transition-colors">Terms</Link>
            <Link to="/admin" className="text-navy-200 hover:text-white text-sm transition-colors">Admin</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
